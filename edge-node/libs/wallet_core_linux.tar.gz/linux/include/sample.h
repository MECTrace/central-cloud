
/* ------------------------------- */
/* Version 0.2.2.1110.cc59 */
/* ------------------------------- */

#ifndef PALLET_CORE_SAMPLE_H
#define PALLET_CORE_SAMPLE_H

#define ADDON_SAMPLE_VER  "0.2.2.1110.cc59"

#ifdef WIN32
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __declspec(dllexport)
#else
#define BC_ADDON_INTERFACE    __declspec(dllimport)
#endif //ADDON_EXPORT
#else
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __attribute__((__visibility__("default")))
#else
#define BC_ADDON_INTERFACE
#endif //ADDON_EXPORT
#endif //WIN32

//주석의 용도는 아래와 같다
//ToCustomizing : Sample제공을 위해 편의상 Penta에서 사용한 로직 ( 반드시 개발측에서 자신에 맞는 방식으로 수정 )
//ToAddon [n] : Addon 개발시 최초 추가해야할 부분 n의 순서에 따라 참조

#ifdef __cplusplus
extern "C" {
#endif

//wallet-core-interface 에서 호출하는 인터페이스 ( 함수 원형은 수정 금지 , 내용은 커스터마이징 인터페이스에 맞춰 수정 )
    BC_ADDON_INTERFACE int RunModule_SAMPLE( const char* szAction , const char* szAddonName , const char* szJson , char** szRet );
//wallet-core-interface 메모리 해지시 사용하는  인터페이스 ( 수정 금지 )
    BC_ADDON_INTERFACE int FreeMem_SAMPLE( char* szRet );

#ifdef __cplusplus
}
#endif

#endif //PALLET_CORE_SAMPLE_H
