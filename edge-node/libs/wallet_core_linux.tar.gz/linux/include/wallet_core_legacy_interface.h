

/* ------------------------------- */
/* Version 0.2.2.1110.cc59 */
/* ------------------------------- */

#ifndef _PALLET_WALLET_CORE_LEGACY_INTERFACE_H_
#define _PALLET_WALLET_CORE_LEGACY_INTERFACE_H_

#define WALLET_CORE_LEGACY_INTERFACE_VER  "0.2.2.1110.cc59"

#ifdef WIN32
#ifdef INTERFACE_EXPORT
    #define WC_INTERFACE    __declspec(dllexport)
#else
    #define WC_INTERFACE    __declspec(dllimport)
#endif //INTERFACE_EXPORT
#else
#ifdef INTERFACE_EXPORT
    #define WC_INTERFACE    __attribute__((__visibility__("default")))
#else
    #define WC_INTERFACE
#endif //INTERFACE_EXPORT
#endif //WIN32

#define PALLET_SUCCESS   0
#define PALLET_FAIL      1
#define PALLET_NEED_ADDSIG_TX 0xF0000000

//BASE58
#define B58_MAP         0
#define B58_XRP_MAP     1

//hash algo define
#define ALGO_NONE_HASH          0
#define ALGO_SHA256             1
#define ALGO_SHA512             2
#define ALGO_RIP160             3

#define ALGO_SHA3_KECCAK224     10
#define ALGO_SHA3_KECCAK256     11
#define ALGO_SHA3_KECCAK384     12
#define ALGO_SHA3_KECCAK512     13

#define GEN_ECDSA_SECP256K1_KGEN_DIGESTLEN  32
#define SHA256_MD_LEN                       32
#define SHA512_MD_LEN                       64
#define RIP160_MD_LEN                       20
#define SHA3_KECCAK224_MD_LEN               28
#define SHA3_KECCAK256_MD_LEN               32
#define SHA3_KECCAK384_MD_LEN               48
#define SHA3_KECCAK512_MD_LEN               64
//#define SIGRLEN                 32
//#define SIGSLEN                 32

#define BC_ECB     1
#define BC_CBC     2

#define COINTYPE_TESTNET             0x0F000000

#define COINTYPE_GEN_ADDRESS         0x00010000
#define COINTYPE_GEN_UNSIGNED_RAWTX  0x00020000
#define COINTYPE_GEN_SIGN_HASH       0x00040000
#define COINTYPE_GEN_SIGN            0x00080000
#define COINTYPE_GEN_SIGNED_RAWTX    0x00100000

//#define MULTISIGN                   0x00F00000

#define COINTYPE_BTCCOIN        0
#define COINTYPE_BTCCOIN_TESTNET        COINTYPE_BTCCOIN+COINTYPE_TESTNET
#define COINTYPE_ETHCOIN        60
#define COINTYPE_ETHCOIN_TESTNET        COINTYPE_ETHCOIN+COINTYPE_TESTNET
#define COINTYPE_BCHCOIN        145
#define COINTYPE_BCHCOIN_TESTNET        COINTYPE_BCHCOIN+COINTYPE_TESTNET
#define COINTYPE_ETCCOIN        61
#define COINTYPE_ETCCOIN_TESTNET        COINTYPE_ETCCOIN+COINTYPE_TESTNET
#define COINTYPE_LTCCOIN        2
#define COINTYPE_LTCCOIN_TESTNET        COINTYPE_LTCCOIN+COINTYPE_TESTNET
#define COINTYPE_XRPCOIN        144
#define COINTYPE_XRPCOIN_TESTNET        COINTYPE_XRPCOIN+COINTYPE_TESTNET
#define COINTYPE_EOSCOIN        194
#define COINTYPE_EOSCOIN_TESTNET        COINTYPE_EOSCOIN+COINTYPE_TESTNET
#define COINTYPE_BSVCOIN        236
#define COINTYPE_BSVCOIN_TESTNET        COINTYPE_BSVCOIN+COINTYPE_TESTNET
#define COINTYPE_BTGCOIN        156
#define COINTYPE_BTGCOIN_TESTNET        COINTYPE_BTGCOIN+COINTYPE_TESTNET

#define COINTYPE_BTCCOIN_INDEX    0
#define COINTYPE_BTCCOIN_TESTNET_INDEX    COINTYPE_BTCCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_ETHCOIN_INDEX    1
#define COINTYPE_ETHCOIN_TESTNET_INDEX    COINTYPE_ETHCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_BCHCOIN_INDEX    2
#define COINTYPE_BCHCOIN_TESTNET_INDEX    COINTYPE_BCHCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_ETCCOIN_INDEX    3
#define COINTYPE_ETCCOIN_TESTNET_INDEX    COINTYPE_ETCCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_LTCCOIN_INDEX    4
#define COINTYPE_LTCCOIN_TESTNET_INDEX    COINTYPE_LTCCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_XRPCOIN_INDEX    5
#define COINTYPE_XRPCOIN_TESTNET_INDEX    COINTYPE_XRPCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_EOSCOIN_INDEX    6
#define COINTYPE_EOSCOIN_TESTNET_INDEX    COINTYPE_EOSCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_BSVCOIN_INDEX    7
#define COINTYPE_BSVCOIN_TESTNET_INDEX    COINTYPE_BSVCOIN_INDEX+COINTYPE_TESTNET
#define COINTYPE_BTGCOIN_INDEX    8
#define COINTYPE_BTGCOIN_TESTNET_INDEX    COINTYPE_BTGCOIN_INDEX+COINTYPE_TESTNET

#define SUPPORT_COIN_COUNT      9

//BTC  0x80000000 0 //UTXO
//LTC  0x80000002 2 //UTXO
//DASH 0x80000005 5 //UTXO???
//ETH  0x8000003c 60
//ETC  0x8000003d 61
//ICX  0x8000004a 74
//XMR  0x80000080 128 //??
//XRP  0x80000090 144
//BCH  0x80000091 145 //UTXO
//BTG  0x8000009c 156 //UTXO
//EOS  0x800000c2 194
//ADA  0x80000717 1815
//QTUM 0x800008fd 2301

#define ERROR_FNAMELINE         64
#define ERROR_FNNAMELINE        64
#define ERROR_MSG_LEN           512

#define MNEMONICLEN             320
// one word 11byte = 10 char (10byte) + space (1byte)
// max 24 word => 11*24 = 264
#define SEEDLEN                 64

#define PRIVLEN                 32
#define PUBLEN                  64
#define PUBLEN_COMP             33
#define PUBLEN_POINT            32
#define CHAINLEN                32
#define SIGLEN                  72

// max pbkdf2(sha512) 64byte

//ERROR CODE ( wrapper )
#define ERR_NOT_SUPPORT_COIN     1
#define ERR_PRAM_NULL            2
#define ERR_BUFFER_SIZE_LOW      3
#define ERR_INVALID_PARAM        4

//core > 1000
#define ERR_CORE_START                    1000
#define ERR_CORE_GENERATE_MNEMONIC        1001
#define ERR_CORE_CONVERT_MNEMONIC_TO_SEED 1002
#define ERR_CORE_GENERATE_LEAFNODE    1003
#define ERR_CORE_GENERATE_CKD             1004
#define ERR_CORE_GENERATE_CKDPUB          1005
#define ERR_CORE_GENERATE_ADDR            1006
#define ERR_CORE_GENERATE_RAWTRANSACTION      1007
#define ERR_CORE_GENERATE_RAWERC20TRANSACTION 1008
#define ERR_CORE_GENERATE_MASTERNODE_FROM_SEED 1009
#define ERR_CORE_CONVERT_HEXSTR_TO_BYTEARRAY 1010
#define ERR_CORE_DO_MESSAGE_DIGEST        1011
#define ERR_CORE_BASE58CHECK_ENCODE       1012
#define ERR_CORE_BASE58CHECK_DECODE       1013
#define ERR_CORE_DERIVE_PUBLICKEY         1014
#define ERR_CORE_BECH32_ENCODE            1015
#define ERR_CORE_BECH32_DECODE            1016
#define ERR_CORE_BASE64_ENCODE            1017
#define ERR_CORE_BASE64_DECODE            1018
#define ERR_CORE_AES_ENCRYPT            1019
#define ERR_CORE_AES_DECRYPT            1020
#define ERR_CORE_GENERATE_ENTROPY       1021
#define ERR_CORE_CHECK_MNEMONIC_VALIDATE 1022
#define ERR_CORE_GETTXOBJECT_INPUTCOUNT  1023
#define ERR_CORE_GETTXOBJECT_INPUTINFO   1024
#define ERR_CORE_GENERATE_ADDSIG_DATA   1025
#define ERR_CORE_CONVERT_TXOBJ_TO_RAWTX  1026
#define ERR_CORE_CONVERT_MNEMONIC_TO_ENTROPY 1027
#define ERR_CORE_CONVERT_MASTER_MNEMONIC_TO_SSS_MNEMONICS 1028
#define ERR_CORE_CONVERT_SSS_MNEMONICS_TO_MASTER_MNEMONIC 1029
#define ERR_CORE_GET_TX_ID  1030
#define ERR_CORE_MERGE_TXOBJECT  1031
#define ERR_CORE_GEN_REDEEM_SCRIPT 1032
#define ERR_CORE_AES_ENCRYPTAUTH            1033
#define ERR_CORE_AES_DECRYPTAUTH            1034
#define ERR_CORE_CHECK_MNEMONIC_WORD_VALIDATE            1035
#define ERR_CORE_GENERATEMASTERNODEFROMSEED_ED  1036
#define ERR_CORE_CKD_ED 1037
#define ERR_CORE_DERIVEPUB_ED 1038
#define ERR_CORE_RUNMODULE		1039

#ifdef __cplusplus
extern "C" {
#endif
    
    /**
     @brief 에러 메시지를 리턴한다.
     @return const char* 에러 메시지
     @see paalet-core 함수의 리턴값이 PALLET_SUCCESS가 아닌경우 호출한다.
     */
    WC_INTERFACE const char *GetPalletLastErr();
    
    /**
     @brief Wallet-Core의 버전을 리턴한다.
     @return const char* 버전
     */
    WC_INTERFACE const char* GetWalletCoreVer();

    /**
     @brief 바이트의 순서를 바꾼다.
     @param pData     [in/out] 데이터 버퍼
     @param nDataLen  [in] 데이터 버퍼 사이즈 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int SwapBytes( unsigned char* pData , const int nDataLen );
    
    /**
     @brief slip44 코인 index를 리턴한다.
     @param nCoinIndex  [in] pallet-core내의 코인별 정의 값
       BTC : COINTYPE_BTCCOIN_INDEX
       BTC_TESTNET : COINTYPE_BTCCOIN_TESTNET_INDEX
       ETH : COINTYPE_ETHCOIN_INDEX
       ETH_TESTNET : COINTYPE_ETHCOIN_TESTNET_INDEX
     @return slip44 코인 index
     @see 참조 링크 https://github.com/satoshilabs/slips/blob/master/slip-0044.md
     @see 참조 링크 https://github.com/satoshilabs/slips/blob/master/slip-0173.md
     */
    WC_INTERFACE int GetSlip44Index(const int nCoinIndex);
    
    /**
     @brief pallet-core의 초기화를 실행한다.
     @see 최초 실행시 한번 호출한다. ( 중복 호출하여도 이미 호출된경우 무시됨 )
     */
    WC_INTERFACE int CoinContext_Init(void);
    
    /**
     @brief 엔트로피(랜덤)값을 생성한다.
     @param entropy  [out] 생성된 엔트로피값이 저장될 버퍼
     @param ent_len  [in] 생성할 엔트로피값의 크기 ( byte단위 )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int GenEntropy(unsigned char* entropy, int ent_len);

    /**
     @brief 현재 runnig된 시스템의 endian을 알아온다.
     @return 1이면 little endian , 0이면 big endian
     */
    WC_INTERFACE int IsLittleEndianSystem(void);
    
    /**
     @brief hex string을 byte array로 변환한다.
     @param byte_arr  [out] 생성된 byte array가 저장될 버퍼
     @param byte_len  [in/out] 생성된 byte array 버퍼의 크기 ( byte )
     @param hex_str   [in] hex string이 저장될 버퍼
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see byte_len는 byte_arr의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see byte_arr의 값을 NULL로 셋팅한후 호출시 byte_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int ConvHexStrToByteArr(unsigned char* byte_arr, int* byte_len, const char* hex_str);
    
    /**
     @brief byte array를 hex string으로 변환한다.
     @param hex_str   [out] 생성된 hex string이 저장될 버퍼
     @param hex_len   [in/out] 생성된 hex string 버퍼의 크기 ( byte ) NULL제외
     @param byte_arr  [in] byte array가 저장될 버퍼
     @param byte_len  [in] byte array버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see hex_len는 hex_str의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see hex_str의 값을 NULL로 셋팅한후 호출시 hex_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int ConvByteArrToHexStr(char* hex_str, int* hex_len, const unsigned char* byte_arr, const int byte_len);
    
    /**
     @brief 대상값을 base64 encode한다.
     @param pOriData     [in] base64 대상 값이 저장될 버퍼
     @param nOriDataLen  [in] base64 대상 값 버퍼의 크기 ( byte )
     @param szOutBuf     [out] 생성된 base64 string 저장될 버퍼
     @param nOutBufLen   [in/out] 생성된 base64 string의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 szOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenBase64Encode( unsigned char* pOriData , int nOriDataLen , char* szOutBuf , int* nOutBufLen );
    
    /**
     @brief base64 encode된값을 base64 decode한다.
     @param szB64E      [in] base64 encode 값이 저장될 버퍼
     @param pOutBuf     [out] 생성된 base64 decode값이 저장될 버퍼
     @param nOutBufLen  [in/out] 생성된 base64 decode값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenBase64Decode( const char* szB64E , unsigned char* pOutBuf , int* nOutBufLen );
    
    /**
     @brief 대상값을 base58check encode한다.
     @param pOriData     [in] base58check 대상 값이 저장될 버퍼
     @param nOriDataLen  [in] base58check 대상 값 버퍼의 크기 ( byte )
     @param szOutBuf     [out] 생성된 base58check string 저장될 버퍼
     @param nOutBufLen   [in/out] 생성된 base58check string의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 szOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenBase58CheckEncode( unsigned char* pOriData , int nOriDataLen , char* szOutBuf , int* nOutBufLen );
    
    /**
     @brief base58check encode된값을 base58 decode한다.
     @param szB58E      [in] base58check encode 값이 저장될 버퍼
     @param pOutBuf     [out] 생성된 base58 decode값이 저장될 버퍼
     @param nOutBufLen  [in/out] 생성된 base58 decode값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see pOutBuf에는 checksum값이 제외한 오리지널 값이 리턴된다.
     */
    WC_INTERFACE int GenBase58CheckDecode( const char* szB58E , unsigned char* pOutBuf , int* nOutBufLen );
    
    /**
     @brief 대상값을 xrp용 base58check encode한다.
     @param pOriData     [in] base58check 대상 값이 저장될 버퍼
     @param nOriDataLen  [in] base58check 대상 값 버퍼의 크기 ( byte )
     @param szOutBuf     [out] 생성된 base58check string 저장될 버퍼
     @param nOutBufLen   [in/out] 생성된 base58check string의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 szOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenXRPBase58CheckEncode( unsigned char* pOriData , int nOriDataLen , char* szOutBuf , int* nOutBufLen );

    /**
    @brief xrp용 base58check encode된값을 base58 decode한다.
    @param szB58E      [in] base58check encode 값이 저장될 버퍼
    @param pOutBuf     [out] 생성된 base58 decode값이 저장될 버퍼
    @param nOutBufLen  [in/out] 생성된 base58 decode값의 크기 ( byte )
    @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
    @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
    @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
    @see pOutBuf에는 checksum값이 제외한 오리지널 값이 리턴된다.
    */
    WC_INTERFACE int GenXRPBase58CheckDecode( const char* szB58E , unsigned char* pOutBuf , int* nOutBufLen );

    /**
     @brief 주어진 값의 hash(digest) 값을 생성 한다.
     @param nMDAlgo      [in] pallet-core에서 정의한 hash알고리즘
     ALGO_SHA256 : sha256 ( 결과값 32byte )
     ALGO_SHA512 : sha512 ( 결과값 64byte )
     ALGO_RIP160 : ripemd160 ( 결과값 20byte )
     ALGO_SHA3_KECCAK256 : sha3-keccat256 ( 결과값 32byte )
     @param pOrigin      [in] hash 대상 값이 저장될 버퍼
     @param nOriginLen   [in] hash 대상 값 버퍼의 크기 ( byte )
     @param pMDigest     [out] 생성된 hash값이 저장될 버퍼
     @param nMDigestLen  [in/out] 생성된 hash값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nMDigestLen는 pMDigest의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pMDigest의 값을 NULL로 셋팅한후 호출시 nMDigestLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see 실제 알고리즘별 리턴되는 결과값은 nMDAlgo param의 결과값 참조
     */
    WC_INTERFACE int GenHashMessage( int nMDAlgo , unsigned char* pOrigin , int nOriginLen , unsigned char* pMDigest , int* nMDigestLen );
    
    /**
     @brief 주어진 값을 AES128-cbc-pkcs5padding or AES128-ecb-pkcs5padding 암호화 한다.
     @param pOriData      [in] 암호화 대상 원본값이 저장될 버퍼
     @param nOriDataLen   [in] 암호화 대상 원본값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param nMode         [in] 암호화 Mode ( BC_ECB or BC_CBC )
     @param pOutBuf       [out] 생성된 암호값이 저장될 버퍼
     @param nOutBufLen    [in/out] 생성된 암호값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nMode의 값은 BC_CBC or BC_CBC 만 지원한다.
     */
    WC_INTERFACE int GenAESEncrypt(const unsigned char* pOriData , int nOriDataLen ,
                      unsigned char* pKey , int nKeyLen , unsigned char* pIV , int nIVLen , int nMode ,
                      unsigned char* pOutBuf , int* nOutBufLen);
    
    /**
     @brief AES128-cbc-pkcs5padding or AES128-ecb-pkcs5padding 로 암호화된 값을 복호화 한다.
     @param pEncData      [in] 복호화 대상 암호값이 저장될 버퍼
     @param nEncDataLen   [in] 복호화 대상 암호값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param nMode         [in] 암호화 Mode ( BC_ECB or BC_CBC )
     @param pOutBuf       [out] 생성된 원본값이 저장될 버퍼
     @param nOutBufLen    [in/out] 생성된 원본값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nMode의 값은 BC_CBC or BC_CBC 만 지원한다.
     */
    WC_INTERFACE int GenAESDecrypt(const unsigned char* pEncData , int nEncDataLen ,
                      unsigned char* pKey , int nKeyLen , unsigned char* pIV , int nIVLen , int nMode ,
                      unsigned char* pOutBuf , int* nOutBufLen);
    
    
    /**
     @brief 주어진 값을 AES128-gcm 암호화 한다.
     @param pOriData      [in] 암호화 대상 원본값이 저장될 버퍼
     @param nOriDataLen   [in] 암호화 대상 원본값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param pAuthData     [in] 인증값이 저장될 버퍼
     @param nAuthDataLen  [in] 인증값 버퍼의 크기 ( byte )
     @param nTagLen        [in] Tag 크기 ( byte )
     @param pOutBuf       [out] 생성된 암호값이 저장될 버퍼
     @param nOutBufLen    [in/out] 생성된 암호값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nTagLen는 16보다 클수없음
     */
    
    WC_INTERFACE int GenAESEncryptAuth(const unsigned char* pOriData , int nOriDataLen ,
                          unsigned char* pKey , int nKeyLen , unsigned char* pIV , int nIVLen ,
                          unsigned char* pAuthData , int nAuthDataLen , int nTagLen ,
                          unsigned char* pOutBuf , int* nOutBufLen);
    
    /**
     @brief AES128-gcm으로 암호화된 값을 복호화 한다.
     @param pEncData      [in] 복호화 대상 암호값이 저장될 버퍼
     @param nEncDataLen   [in] 복호화 대상 암호값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param pAuthData     [in] 인증값이 저장될 버퍼
     @param nAuthDataLen  [in] 인증값 버퍼의 크기 ( byte )
     @param nTagLen        [in] Tag 크기 ( byte )
     @param pOutBuf       [out] 생성된 원본값이 저장될 버퍼
     @param nOutBufLen    [in/out] 생성된 원본값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nTagLen는 16보다 클수없음
     */
    
    WC_INTERFACE int GenAESDecryptAuth(const unsigned char* pEncData , int nEncDataLen ,
                          unsigned char* pKey , int nKeyLen , unsigned char* pIV , int nIVLen ,
                          unsigned char* pAuthData , int nAuthDataLen , int nTagLen ,
                          unsigned char* pOutBuf , int* nOutBufLen);
    
    /**
     @brief 엔트로피값으로 니모닉을 생성한다.
     @param entropy      [in] 엔트로피값이 저장된 버퍼
     @param entropy_len  [in] 엔트로피 버퍼 사이즈 ( byte )
     @param buf          [out] 생성된 니모닉이 저장될 버퍼
     @param buf_len      [in/out] 생성된 니모닉 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see buf(생성된 니모닉)의 단어별 구분은 스페이스
     @see buf_len는 buf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see buf의 값을 NULL로 셋팅한후 호출시 buf_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenMnemonic(const unsigned char* entropy, const int entropy_len,
                    char* buf, int* buf_len);

    /**
     @brief 니모닉값으로 Master Seed값을 생성한다.
     @param szMnemonics   [in] 니모닉값이 저장된 버퍼
     @param szPassPharse  [in] 니모닉 유도를 위한 패스워드
     @param buf           [out] 생성된 Master Seed가 저장될 버퍼
     @param buf_len       [in/out] 생성된 Master Seed 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see szMnemonics(생성된 니모닉)의 단어별 구분은 스페이스
     @see szPassPharse의 default값은 ""
     @see buf_len는 buf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see buf의 값을 NULL로 셋팅한후 호출시 buf_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int ConvMnemonicToSeed(const char* szMnemonics,
                           const char* szPassPharse,
                           unsigned char* buf, int* buf_len);
    
    /**
     @brief 마스터 니모닉값에서 시크릿 쉐어 니모닉 값들을 유도한다.
     @param szMMnemonic       [in] 마스터 니모닉값이 저장된 버퍼
     @param nTotalSSSMSCount  [int] 마스터 니모닉에 대한 전체 시크릿 니모닉의 갯수
     @param nNeedSSSMSCount   [in] 마스터 니모닉을 유도할 최소 시크릿 쉐어 니모닉의 갯수
     @param szSMnemonics      [out] 시크릿 쉐어 니모닉들이 저장될 버퍼
     @param nSMnemonicsLen    [in/out] 생성된 szSMnemonics 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see szMMnemonic(생성된 니모닉)의 단어별 구분은 스페이스
     @see nSMnemonicsLen는 szSMnemonics의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szSMnemonics의 값을 NULL로 셋팅한후 호출시 nSMnemonicsLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see 마스터 니모닉을 Entpropy로 치환 sharmir-secret-sharing을 이용 nTotalSSSMSCount개 만큼의 시크릿 쉐어 값을 시크릿 쉐어 니모닉으로 변환
     @see szSMnemonics의 니모닉별 구분자은 \n 이며 , 각 니모닉값의 단어별 구분은 스페이스임
     */
    WC_INTERFACE int ConvMasterMnemonicToSSSMnemonic(const char* szMMnemonic,
                                        int nTotalSSSMSCount, int nNeedSSSMSCount,
                                        char* szSMnemonics, int* nSMnemonicsLen);
    
    /**
     @brief 시크릿 쉐어 니모닉값에서 마스터 니모닉 값을 유도한다.
     @param szSMnemonics   [in] 시크릿 쉐어 니모닉값들이 저장된 버퍼
     @param szMMnemonics   [out] 마스터 니모닉이 저장될 버퍼
     @param nMMnemonicLen  [in/out] 생성된 szMMnemonics 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see szSMnemonics의 니모닉별 구분자은 \n 이며 , 각 니모닉값의 단어별 구분은 스페이스임
     @see szMMnemonics는 nMMnemonicLen의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szMMnemonics의 값을 NULL로 셋팅한후 호출시 nMMnemonicLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see szMMnemonics의 각 단어별 구분은 스페이스임
     */
    WC_INTERFACE int ConvSSSMnemonicToMasterMnemonic(const char* szSMnemonics,
                                        char* szMMnemonics, int* nMMnemonicLen);
    
    /**
     @brief 니모닉값의 유효성을 체크한다. ( 유효한 단어들로 이루어졌는지 , 니모닉 -> 엔트로피 : 체크섬값이 유효한지 )
     @param szMnemonics  [in] 니모닉값이 저장된 버퍼
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int ChkMnemonicValid(const char* szMnemonics);
    
    /**
     @brief 니모닉 단어값의 유효성을 체크한다. ( 유효한 단어인지 )
     @param szWord  [in] 니모닉 단어값이 저장된 버퍼
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int ChkMnemonicWordValid(const char* szWord);
    
    WC_INTERFACE int ConvMNemonicToEntropy(const char* szMnemonics, unsigned char* pEnt, int* nEntLen);
    
    /**
     @brief 마스터 노드를 생성한다. ( bip44 m' )
     @param master_seed      [in] Master Seed값이 저장된 버퍼
     @param master_seed_len  [in] Master Seed 버퍼 사이즈 ( byte )
     @param priv_key         [out] 생성된 마스터 노드의 개인키가 저장될 버퍼
     @param priv_len         [in/out] 생성된 마스터 노드의 개인키 버퍼의 크기 ( byte )
     @param pub_key          [out] 생성된 마스터 노드의 공개키가 저장될 버퍼
     @param pub_len          [in/out] 생성된 마스터 노드의 공개키 버퍼의 크기 ( byte )
     @param chain_code       [out] 생성된 마스터 노드의 체인코드가 저장될 버퍼
     @param chain_len        [in/out] 생성된 마스터 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위한 GenCKD/GenCKDPub를 호출하기 위한 마스터 노드 생성을 위해 호출한다.
     @see priv_len/pub_len/chain_len는 priv_key/pub_key/chain_code의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see priv_key/pub_key/chain_code의 값을 NULL로 셋팅한후 호출시 priv_len/pub_len/chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenMasterNode(const unsigned char* master_seed, const unsigned int master_seed_len,
                      unsigned char* priv_key, unsigned int* priv_len,
                      unsigned char* pub_key, unsigned int* pub_len,
                      unsigned char* chain_code, unsigned int* chain_len);
    
    /**
     @brief 부모 노드로 부터 자식 노드를 생성한다. ( bip44 m'/.... )
     @param par_priv_key      [in] 부모 노드의 개인키값이 저장된 버퍼
     @param par_priv_len      [in] 노드의 개인키 버퍼 사이즈 ( byte )
     @param par_pub_key       [in] 부모 노드의 공개키값이 저장된 버퍼
     @param par_pub_len       [in] 노드의 공개키 버퍼 사이즈 ( byte )
     @param par_chain_code    [in] 부모 노드의 체인코드값이 저장된 버퍼
     @param par_chain_len     [in] 노드의 체인코드 버퍼 사이즈 ( byte )
     @param index             [in] 자식 노드의 index
     @param child_priv_key    [out] 생성된 자식 노드의 개인키가 저장될 버퍼
     @param child_priv_len    [in/out] 생성된 자식 노드의 개인키 버퍼의 크기 ( byte )
     @param child_pub_key     [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param child_pub_len     [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param child_chain_code  [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param child_chain_len   [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위해서 호출한다.
     @see hardened 자식노드를 호출하기 위해서는 index값에 0x80000000를 더해준다.
     @see child_priv_len/child_pub_len/child_chain_len는 child_priv_key/child_pub_key/child_chain_code의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see child_priv_key/child_pub_key/child_chain_code의 값을 NULL로 셋팅한후 호출시 child_priv_len/child_pub_len/child_chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenCKD(const unsigned char* par_priv_key, int par_priv_len,
               const unsigned char* par_pub_key, int par_pub_len,
               const unsigned char* par_chain_code, int par_chain_len,
               const int index,
               unsigned char* child_priv_key, int* child_priv_len,
               unsigned char* child_pub_key, int* child_pub_len,
               unsigned char* child_chain_code, int* child_chain_len);
           
    /**
     @brief 부모 노드로 부터 자식 노드의 공개키를 생성한다. ( bip44 m'/.... )
     @param par_pub_key       [in] 부모 노드의 공개키값이 저장된 버퍼
     @param par_pub_len       [in] 노드의 공개키 버퍼 사이즈 ( byte )
     @param par_chain_code    [in] 부모 노드의 체인코드값이 저장된 버퍼
     @param par_chain_len     [in] 노드의 체인코드 버퍼 사이즈 ( byte )
     @param index             [in] 자식 노드의 index
     @param child_pub_key     [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param child_key_len     [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param child_chain_code  [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param child_chain_len   [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위해서 호출한다.
     @see 부모->자식 생성시 공개키로 유도시는 hardened 자식노드의 생성은 불가함
     @see child_pub_len/child_chain_len는 child_pub_key/child_chain_code의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see child_pub_key/child_chain_code의 값을 NULL로 셋팅한후 호출시 child_pub_len/child_chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenCKDPub(const unsigned char* par_pub_key, int par_pub_len,
                  const unsigned char* par_chain_code, int par_chain_len,
                  const int index,
                  unsigned char* child_pub_key, int* child_key_len,
                  unsigned char* child_chain_code, int* child_chain_len);

    /**
     @brief Master Seed로 부터 리프 노드를 생성한다. ( bip44 m/purpose'[0x8000002c]/coin_type'[0x80000000+Slip44Index]/account'[0x80000000]/change[0]/address_index[address_index] )
     @param coin_type        [in] pallet-core내의 코인별 정의 값
       BTC : COINTYPE_BTCCOIN
       BTC_TEST : COINTYPE_BTCCOIN_TESTNET
       ETH : COINTYPE_ETHCOIN
       ETHERC20 : COINTYPE_ETHTOKEN
       ETH_TEST : COINTYPE_ETHCOIN_TESTNET
     @param master_seed      [in] Master Seed값이 저장된 버퍼
     @param master_seed_len  [in] Master Seed 버퍼 사이즈 ( byte )
     @param address_index    [in] 자식 노드의 address index
     @param priv_key         [out] 생성된 자식 노드의 개인키가 저장될 버퍼
     @param priv_len         [in/out] 생성된 자식 노드의 개인키 버퍼의 크기 ( byte )
     @param pub_key          [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param pub_len          [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param chain_code       [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param chain_len        [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see priv_len/pub_len/chain_len는 priv_key/pub_key/chain_code의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see priv_key/pub_key/chain_code의 값을 NULL로 셋팅한후 호출시 priv_len/pub_len/chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenLeafNode(const int coin_type,
                    const unsigned char* master_seed, int master_seed_len,
                    const int address_index,
                    unsigned char* priv_key, int* priv_len,
                    unsigned char* pub_key, int* pub_len,
                    unsigned char* chain_code, int* chain_len);
    
    /**
     @brief Master Seed로 부터 리프 노드를 생성한다. ( bip44 m/purpose'[0x8000002c]/coin_type'[0x80000000+Slip44Index]/account'[0x80000000]/change[0]/address_index[address_index] )
     @param purpose          [in] 자식 노드의 purpose'
     @param coin_type        [in] 자식 노드의 coin type'
     @param account_index    [in] 자식 노드의 account' index
     @param change_index     [in] 자식 노드의 chnage index
     @param address_index    [in] 자식 노드의 address index
     @param master_seed      [in] Master Seed값이 저장된 버퍼
     @param master_seed_len  [in] Master Seed 버퍼 사이즈 ( byte )
     @param priv_key         [out] 생성된 자식 노드의 개인키가 저장될 버퍼
     @param priv_len         [in/out] 생성된 자식 노드의 개인키 버퍼의 크기 ( byte )
     @param pub_key          [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param pub_len          [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param chain_code       [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param chain_len        [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see 테스트용임 절대 실제 서비스에서는 사용금지
     @see bip44패스 입력 ( default m/purpose(42)'/coin_type(slip44)'/account_index(0)'/change(0)/address(0) )
     @see priv_key/pub_key/chain_code의 값을 NULL로 셋팅한후 호출시 priv_len/pub_len/chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenPathLeafNode(const int purpose, const int coin_type, const int account_index, const int change_index, const int address_index,
                        const unsigned char* master_seed, int master_seed_len,
                        unsigned char* priv_key, int* priv_len,
                        unsigned char* pub_key, int* pub_len,
                        unsigned char* chain_code, int* chain_len);
    
    /**
     @brief specp256k1 개인키(32byte)로 부터 압축된 공개키(33byte)를 생성한다.
     @param priv_key  [in] 개인키값이 저장된 버퍼
     @param priv_len  [in] 개인키 버퍼 사이즈 ( byte )
     @param pub_key   [out] 생성된 공개키가 저장될 버퍼
     @param pub_len   [in/out] 생성된 공개키 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see 생성된 공개키는 압축된 형태임 ( 1byte[prefix : y is odd(0x03) or even(0x02)]+32byte[public key's x point] )
     @see pub_len는 pub_key의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pub_key의 값을 NULL로 셋팅한후 호출시 pub_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenPubkeyFromPriKey(const unsigned char* priv_key, int priv_len, unsigned char* pub_key, int* pub_len);
    
    WC_INTERFACE int GenSignature(const unsigned char* pPri, const int nPriLen,
                     const int nHashAlgo, const unsigned char* pMsg, const int nMsgLen, const int nUseOriSigS,
                     unsigned char* pSigR, int* nSigRLen, unsigned char* pSigS, int* nSigSLen, int* nRecovery);
    
    WC_INTERFACE int VerifySignature(const unsigned char* pPub , const int nPubLen ,
                        const unsigned char* pSigR , const int nSigRLen , const unsigned char* pSigS , const int nSigSLen ,
                        const int nHashAlgo , const unsigned char* pMsg , const int nMsgLen );
    
    /**
     @brief ED25519를 지원하는 마스터 노드를 생성한다. ( bip44 m' )
     @param pMasterSeed      [in] Master Seed값이 저장된 버퍼
     @param nMasterSeedLen   [in] Master Seed 버퍼 사이즈 ( byte )
     @param pPri             [out] 생성된 마스터 노드의 개인키가 저장될 버퍼
     @param nPriLen          [in/out] 생성된 마스터 노드의 개인키 버퍼의 크기 ( byte )
     @param pPub             [out] 생성된 마스터 노드의 공개키가 저장될 버퍼
     @param nPubLen          [in/out] 생성된 마스터 노드의 공개키 버퍼의 크기 ( byte )
     @param pChainCode       [out] 생성된 마스터 노드의 체인코드가 저장될 버퍼
     @param nChainCodeLen    [in/out] 생성된 마스터 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위한 GenCKD_ED를 호출하기 위한 마스터 노드 생성을 위해 호출한다.
     @see nPriLen/nPubLen/nChainCodeLen는 pPri/pPub/pChainCode의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pPri/pPub/pChainCode의 값을 NULL로 셋팅한후 호출시 nPriLen/nPubLen/nChainCodeLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenMasterNode_ED(const unsigned char* pMasterSeed , const int nMasterSeedLen ,
                         unsigned char* pPri , int* nPriLen ,
                         unsigned char* pPub , int* nPubLen ,
                         unsigned char* pChainCode , int* nChainCodeLen );
    
    /**
     @brief ED25519를 지원하는 부모 노드로 부터 자식 노드를 생성한다. ( bip44 m'/.... )
     @param pPPri          [in] 부모 노드의 개인키값이 저장된 버퍼
     @param nPPriLen       [in] 노드의 개인키 버퍼 사이즈 ( byte )
     @param pPPub          [in] 부모 노드의 공개키값이 저장된 버퍼
     @param nPPubLen       [in] 노드의 공개키 버퍼 사이즈 ( byte )
     @param pPChainCode    [in] 부모 노드의 체인코드값이 저장된 버퍼
     @param nPChainCodeLen [in] 노드의 체인코드 버퍼 사이즈 ( byte )
     @param nIndex          [in] 자식 노드의 index
     @param pCPri          [out] 생성된 자식 노드의 개인키가 저장될 버퍼
     @param nCPriLen       [in/out] 생성된 자식 노드의 개인키 버퍼의 크기 ( byte )
     @param pCPub          [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param nCPubLen       [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param pCChainCode    [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param nCChainCodeLen [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위해서 호출한다.
     @see hardened만 지원하기때문 nIndex값은 0x80000000이상이여야함.
     @see nCPriLen/nCPubLen/nCChainCodeLen는 pCPri/pCPub/pCChainCode의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pCPri/pCPub/pCChainCode의 값을 NULL로 셋팅한후 호출시 nCPriLen/nCPubLen/nCChainCodeLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenCKD_ED(const unsigned char* pPPri, int nPPriLen,
                  const unsigned char* pPPub, int nPPubLen,
                  const unsigned char* pPChainCode, int nPChainCodeLen,
                  const int nIndex,
                  unsigned char* pCPri, int* nCPriLen,
                  unsigned char* pCPub, int* nCPubLen,
                  unsigned char* pCChainCode, int* nCChainCodeLen);
    
    /**
     @brief ED25519 개인키(32byte)로 부터 공개키(32byte)를 생성한다.
     @param pPri     [in] 개인키값이 저장된 버퍼
     @param pPriLen  [in] 개인키 버퍼 사이즈 ( byte )
     @param pPub     [out] 생성된 공개키가 저장될 버퍼
     @param nPubLen  [in/out] 생성된 공개키 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nPubLen는 pPub의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pPub의 값을 NULL로 셋팅한후 호출시 nPubLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GenPubkeyFromPriKey_ED(const unsigned char* pPri , int pPriLen , unsigned char* pPub , int* nPubLen );
    
    WC_INTERFACE int GenSignature_ED(const unsigned char* pPri , const int nPriLen ,
                        const unsigned char* pMsg , const int nMsgLen ,
                        const unsigned char* pContext , const int nContextLen ,
                        const unsigned char cUsePh ,
                        unsigned char* pOut , int* nOutLen );
    
    WC_INTERFACE int VerifySignature_ED(const unsigned char* pSig , const int nSigLen ,
                           const unsigned char* pPub , const int nPubLen ,
                           const unsigned char* pMsg , const int nMsgLen ,
                           const unsigned char* pContext , const int nContextLen ,
                           const unsigned char cUsePh );
    
    
    /**
     @brief coin_type 따른 주소를 생성한다.
     @param coin_type      [in] pallet-core내의 코인별 정의 값
       BTC : COINTYPE_BTCCOIN
       BTC_TEST : COINTYPE_BTCCOIN_TESTNET
       ETH : COINTYPE_ETHCOIN
       ETHERC20 : COINTYPE_ETHTOKEN
       ETH_TEST : COINTYPE_ETHCOIN_TESTNET
     @param szAddressInfo  [in] 생성할 주소의 정보 ( json type )
     @param coin_addr      [out] 생성된 주소가 저장될 버퍼
     @param coin_addr_len  [in/out] 생성된 주소 버퍼의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see 생성된 주소는 char* 형태임 마지막에 NULL이 있음
     @see coin_addr_len는 coin_addr의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see coin_addr의 값을 NULL로 셋팅한후 호출시 coin_addr_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see BTC p2pkh의 경우 msig값은 무시되며 , pubs의 제일 첫번째 값만 사용한다.
     @see ETH 의 경우 모든 값이 무시되며 , pubs의 제일 첫번째 값만 사용한다.
     @see szAddressInfo BTC p2pkh or p2wpkh or p2sh(p2wpkh) {"addr_type":"p2pkh","pubs":[{"pub":"pubx[33byte]"}]}
     @see szAddressInfo BTC p2sh or p2wsh or p2sh(p2wsh)( m-of-n multisig addr )  {"addr_type":"p2sh","msig":[{"needsigcount":"m","totalsigcount":"n"}],"pubs":[{"pub":"1th pubx[33byte]"},...,{"pub":"nth pubx[33byte]"}]}
     @see szAddressInfo ETH {"pubs":[{"pub":"pubx[33byte]"}}
     ex> BTC p2pkh {"addr_type":"p2pkh","pubs":[{"pub":"033B7771C01DA8BE061D4947A399BE8F55EF84B910B31CF24D3F4ECBD3FC7BD04A"}]}
     ex> BTC p2sh(2-of-3) {"addr_type":"p2sh",
                              "msig":[{"needsigcnt":"2","totalsigcnt":"3"}],
                              "pubs":[{"pub":"033B7771C01DA8BE061D4947A399BE8F55EF84B910B31CF24D3F4ECBD3FC7BD04A"},
                                {"pub":"0273F77AFE6CC6EA7C94F8EB31F31BAAD166AFB3A34F9AA5AF9DC7A23D9D372315"},
                                {"pub":"02FE7FFE45F56A08989B8B7449109F16E29118EC728B475076E9BF6ADB727C722D"}]}
     ex> ETH {"pubs":[{"pub":"02841B0045EE5B691BACDAEF6526E23D37A1B2F1E93B6E207C1B99CDB971379A00"}]}
     */
    WC_INTERFACE int GenAddr(const int coin_type,
                const char* szAddressInfo,
                char* coin_addr, int* coin_addr_len);
    
    /**
     @brief coin_type 따른 Redeem script를 생성한다. ( BTC 만 적용 )
     @param coin_type      [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     @param szAddressInfo  [in] 생성할 Redeem script의 정보 ( json type ) GenAddr동일한 값
     @param pRedeems       [out] 생성된 Redeem script가 저장될 버퍼
     @param nRedeemsLen    [in/out] 생성된 Redeem script 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nRedeemsLen는 pRedeems의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pRedeems의 값을 NULL로 셋팅한후 호출시 nRedeemsLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see szAddressInfo는 GenAddr의 BTC와 동일 ( p2sh만 지원 )
     */
    WC_INTERFACE int GenRedeems(const int coin_type,
                   const char* szAddressInfo,
                   unsigned char* pRedeems, int* nRedeemsLen);

    /**
     @brief coin_type 따른 주소를 생성한다.
     @param coin_type      [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     ETH : COINTYPE_ETHCOIN
     ETHERC20 : COINTYPE_ETHTOKEN
     ETH_TEST : COINTYPE_ETHCOIN_TESTNET
     @param szTxInfo       [in] 생성할 주소의 정보 ( json type )
     @param nIsNeedAddSig  [out] 현재 transaction에 추가 서명이 필요 여부 ( multisig 추가가 필요한지 여부 )( 1 서명 추가 필요 , 0 필요한 서명이 추가 완료 )
     @param pRawTx         [out] 생성된 중간 서명 값이 저장될 버퍼
     @param nRawTxLen      [in/out] 생성된 중간 서명 값 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see 생성된 값은 중간 주소 값이므 ConvPalletTxToRawTx으로 transaction으로 변경해야 network에 broadcast가능함 ( BTC만 적용 )
     @see nRawTxLen는 pRawTx의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pRawTx의 값을 NULL로 셋팅한후 호출시 nRawTxLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see BTC tx인경우 redeems값이 존재하지 않는경우 일반 tx로 인식 ( redeems가 존재하는 경우 needsigcnt, totalsigcnt는 반드시 존재해야함 )
     @see BTC tx인경우 prevalue, value값은 satoshi단위 decimal값임
     @see ETH 의 경우 value값을 제외한 숫자값(nonce,gasprice:wei,gaslimit:wei)은 decimal로 입력한다. ( value:wei값은 biginteger-big endian-를 hex string으로 변환하여 입력한다. )
     @see BTC common {"input_count":"input(utxo) 갯수","input":[1th inputinfo,...,nth inputinfo],"output_count":"output갯수","output":[1th outputinfo,...,mth outputinfo]}
     @see BTC inputinfo p2pkh {"pri":"서명할개인키:hexstr","prehex":"이전txid:hexstr","preidx":"이전tx_output_index:dec","prespub":"utxo_scriptpub:hexstr","prevalue":"utxo_vlaue:dec:satoshi"}
     @see BTC inputinfo p2sh(multisig m-of-n) {"pri":"상동","prehex":"상동","preidx":"상동","prespub":"상동","prevalue":"상동","redeems":"공용주소생성redeem","needsigcnt":"m:dec","totalsigcnt":"n:dec"}
     @see BTC outputinfo {"value":"보낼금액:dec:stoshi","dest":"보낼주소"}
     @see ETH 일반 {"pri":"서명할개인키:hexstr","nonce":"마지막nonce값:dec","gasprice":"wei:dec","gaslimit":"wei:dec","to":"보낼주소:hexstr","value":"보낼eth값:wei:hexstr:bigendian"}
     @see ETH ERC20 {"pri":"서명할개인키:hexstr","nonce":"마지막nonce값:dec","gasprice":"wei:dec","gaslimit":"wei:dec-","to":"","value":"","contract":[ERC20Info]}
     @see ETH ERC20Info {"addr":"contract주소:hexstr","to":"토큰을 보낼 주소:hexstr","value":"토큰량:hexstr:bigendian"}
     ex> BTC 일반 {"input_count":"1",
     "input":[
       {"pri":"유저개인키",
        "prehex":"39d4472aab66a6d3ad5f1a375f371916344349d2a101fe39c90799f19e3be746",
        "preidx":"1","prespub":"76a9146f5ecaa87679c58f114150b9070216e5d6f3da4988ac","prevalue":"16000"}],
     "output_count":"2",
     "output":[
       {"value":"12480","dest":"148oevH4HL9ok7eMsDTRNfyx86svFF2Ysi"},
       {"value":"578020","dest":"1B9sZXpJuFdCzJGsFEMvHNpLAXtu3FX4ex"}]}
     ex> BTC 일반 다대다 전송(n-m전송) {"input_count":"2",
     "input":[
       {"pri":"유저1개인키",
        "prehex":"717c1c5c09b076d9d26c8afc35aac4d8aff2b46ada060da3bf57bcacaa8cc064",
        "preidx":"1","prespub":"76a9146f5ecaa87679c58f114150b9070216e5d6f3da4988ac","prevalue":"600000"},
       {"pri":"유저2개인키",
        "prehex":"1868fe6c7c9db70b41348ce93499055f5bdf7d7ae192a6190d565851d00460eb",
        "preidx":"0","prespub":"76a9146f5ecaa87679c58f114150b9070216e5d6f3da4988ac","prevalue":"10000"}],
     "output_count":"2",
     "output":[
       {"value":"10000","dest":"148oevH4HL9ok7eMsDTRNfyx86svFF2Ysi"},
       {"value":"595000","dest":"1B9sZXpJuFdCzJGsFEMvHNpLAXtu3FX4ex"}]}
     ex> BTC 멀티시그(2-of-3)
     {"input_count":"1",
     "input":[
       {"pri":"멀티시그유저1개인키",
        "prehex":"39d4472aab66a6d3ad5f1a375f371916344349d2a101fe39c90799f19e3be746",
        "preidx":"1","prespub":"76a9146f5ecaa87679c58f114150b9070216e5d6f3da4988ac","prevalue":"16000"}],
     "output_count":"2",
     "output":[
       {"value":"12480","dest":"148oevH4HL9ok7eMsDTRNfyx86svFF2Ysi"},
       {"value":"578020","dest":"1B9sZXpJuFdCzJGsFEMvHNpLAXtu3FX4ex"}]}
     ex> BTC 멀티시그(2-of-3) + 다대다 전송(m-n전송)
     {"input_count":"1",
     "input":[
       {"pri":"유저1개인키",
        "prehex":"717c1c5c09b076d9d26c8afc35aac4d8aff2b46ada060da3bf57bcacaa8cc064",
        "preidx":"1","prespub":"76a9146f5ecaa87679c58f114150b9070216e5d6f3da4988ac","prevalue":"600000"},
       {"pri":"유저2개인키",
        "prehex":"1868fe6c7c9db70b41348ce93499055f5bdf7d7ae192a6190d565851d00460eb",
        "preidx":"0","prespub":"76a9146f5ecaa87679c58f114150b9070216e5d6f3da4988ac","prevalue":"10000"},
       {"pri":"멀티시그유저1개인키",
        "prehex":"39d4472aab66a6d3ad5f1a375f371916344349d2a101fe39c90799f19e3be746",
        "preidx":"1","prespub":"76a9146f5ecaa87679c58f114150b9070216e5d6f3da4988ac","prevalue":"16000"}],
     "output_count":"2",
     "output":[
       {"value":"10000","dest":"148oevH4HL9ok7eMsDTRNfyx86svFF2Ysi"},
       {"value":"595000","dest":"1B9sZXpJuFdCzJGsFEMvHNpLAXtu3FX4ex"},
       {"value":"12480","dest":"148oevH4HL9ok7eMsDTRNfyx86svFF2Ysi"},
       {"value":"578020","dest":"1B9sZXpJuFdCzJGsFEMvHNpLAXtu3FX4ex"}]}
     ex> ETH 일반 {"pri":"유저개인키",
                  "nonce":"5","gasprice":"77359400","gaslimit":"5208",
                  "to":"abec96e1e3659f7152976d5a14a246399d801b03","value":"6a94d74f430000"}
     ex> ETH ERC20 {"pri":"유저개인키",
                    "nonce":"14","gasprice":"2000000000","gaslimit":"21000","to":"","value":"",
                    "contract":[
                      {"addr":"38c87aa89b2b8cd9b95b736e1fa7b612ea972169","to":"9693EE2BAEC84296249337C4BC7AE51E6C3D0302","value":"100040575AB7861A00000"}]}
     */
    WC_INTERFACE int GenRawTx(const int coin_type,
                 const char* szTxInfo,
                 int* nIsNeedAddSig,
                 unsigned char* pRawTx, int* nRawTxLen);

    /**
     @brief 중간 서명값(GenRawTx로 부터 받은값)의 input의 갯수를 가져온다. ( BTC만 해당 )
     @param coin_type     [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     @param pPalletTxBuf     [in] 중간 서명값이 저장된 버퍼
     @param nPalletTxBufLen  [in] 중간 서명값 버퍼의 크기 ( byte )
     @param nInputCount      [in/out] 중간 서명값에 존재하는 input의 갯수
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int GetPalletTxInputCount(const int coin_type,
                              unsigned char* pPalletTxBuf, int nPalletTxBufLen,
                              int* nInputCount);

    /**
     @brief 중간 서명값(GenRawTx로 부터 받은값)의 input의 정보를 가져온다. ( BTC만 해당 )
     @param coin_type     [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     @param pPalletTxBuf     [in] 중간 서명값이 저장된 버퍼
     @param nPalletTxBufLen  [in] 중간 서명값 버퍼의 크기 ( byte )
     @param nInputIndex      [in] 체크해볼 input의 index
     @param pPri             [in] 개인키값이 저장된 버퍼
     @param nPriLen          [in] 개인키 버퍼 사이즈 ( byte )
     @param nIsAddSigInput   [out] 현재 input에 서명을 pri로 추가 가능한지 여부 체크( 1 서명 추가 필요 , 0 필요한 서명이 추가 완료 )
     @param nTotalSigCount   [out] 현재 input에 m-of-n의 n값
     @param nNeedSigCount    [out] 현재 input에 m-of-n의 m값
     @param nAddSigCount     [out] 현재 input에 추가되어있는 서명의 갯수
     @see pPri값이 존재할때만 nIsAddSigInput정보가 유효함
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int GetPalletTxInputSigInfo(const int coin_type,
                                unsigned char* pPalletTxBuf, int nPalletTxBufLen,
                                unsigned char* pPri, int nPriLen,
                                int nInputIndex,
                                int* nIsAddSigInput, int* nTotalSigCount, int* nNeedSigCount, int* nAddSigCount);
    
    /**
     @brief 중간 서명값(GenRawTx로 부터 받은값)의 input에 전자서명을 생성한다. ( BTC만 해당 )
     @param coin_type     [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     @param pPalletTxBuf           [in] 중간 서명값이 저장된 버퍼
     @param nPalletTxBufLen        [in] 중간 서명값 버퍼의 크기 ( byte )
     @param nInputIndex            [in] 체크해볼 input의 index
     @param pPri                   [in] 개인키값이 저장된 버퍼
     @param nPriLen                [in] 개인키 버퍼 사이즈 ( byte )
     @param nIsNeedAddSig          [out] 현재 input에 서명을 더 추가해야 하는지 여부 체크( 1 서명 추가 필요 , 0 필요한 서명이 추가 완료 )
     @param pAddSigData     [out] pPri로 생성된 전자서명값이 저장될 버퍼
     @param nAddSigDataLen  [in/out] pPri로 생성된 전자서명값이 저장될 버퍼사이즈(byte)
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nAddSigDataLen는 pAddSigData의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pAddSigData의 값을 NULL로 셋팅한후 호출시 nAddSigDataLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see pAddSigData는 input idx | redeem idx | Sig
     */
    WC_INTERFACE int GenAddSigData(const int coin_type,
                      unsigned char* pPalletTxBuf, int nPalletTxBufLen,
                      int nInputIndex,
                      unsigned char* pPri, int nPriLen,
                      int* nIsNeedAddSig,
                      unsigned char* pAddSigData, int* nAddSigDataLen);
    
    /**
     @brief 별도의 사용자들이 서명값(GenAddSigData로 부터 받은값)을 중간 서명값(GenRawTx로 부터 받은값)에 추가한다. ( BTC만 해당 )
     @param coin_type     [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     @param pOriPalletTxBuf       [in] 서명값을 추가할 중간 서명값이 저장된 버퍼
     @param npOriPalletTxBufLen    [in] 서명값이 추가될 중간 서명값 버퍼의 크기 ( byte )
     @param szAddSigInfo       [in] 추가할 서명의 정보 ( json type )
     @param pMerPalletTxBuf     [out] 서명이 합쳐진 중간 서명값 버퍼가 저장될 버퍼
     @param nMerPalletTxBufLen  [in/out] 서명이 합쳐진 중간 서명값 버퍼가 저장될 버퍼의 버퍼사이즈(byte)
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nMerPalletTxBufLen는 pMerPalletTxBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pMerPalletTxBuf의 값을 NULL로 셋팅한후 호출시 nMerPalletTxBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see {"add_sig_count":"추가될 sig갯수","add_sigs":[{"add_sig":"siginfo GenAddSigData"},...,{"add_sig":"siginfo GenAddSigData"}]}
     */
    WC_INTERFACE int MerPalletTx(const int coin_type,
                    unsigned char* pOriPalletTxBuf, int npOriPalletTxBufLen,
                    char* szAddSigInfo,
                    unsigned char* pMerPalletTxBuf, int* nMerPalletTxBufLen);
    
    /**
     @brief 중간 서명값을 실제 raw transaction으로 변환한다. ( BTC만 해당 )
     @param coin_type     [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     @param pPalletTxBuf     [in] 변경할 중간 서명값이 저장된 버퍼
     @param nPalletTxBufLen  [in] 변경할 중간 서명값 버퍼의 크기 ( byte )
     @param pRawTx           [out] raw transaction 버퍼가 저장될 버퍼
     @param nRawTxLen        [in/out] raw transaction 버퍼가 저장될 버퍼의 버퍼사이즈(byte)
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nRawTxLen는 pRawTx의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pRawTx의 값을 NULL로 셋팅한후 호출시 nRawTxLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int ConvPalletTxToRawTx(const int coin_type,
                            unsigned char* pPalletTxBuf, int nPalletTxBufLen,
                            unsigned char* pRawTx, int* nRawTxLen);
    
    /**
     @brief raw transaction값을 이용하여 transaction id를 생성한다. ( BTC만 해당 )
     @param coin_type     [in] pallet-core내의 코인별 정의 값
     BTC : COINTYPE_BTCCOIN
     BTC_TEST : COINTYPE_BTCCOIN_TESTNET
     @param pRawTx     [in] transaction id를 생성할 raw transaction값이 저장된 버퍼
     @param nRawTxLen  [in] transaction id를 생성할 raw transaction값의 버퍼 크기 ( byte )
     @param pTxID      [out] transaction id 버퍼가 저장될 버퍼
     @param nTxIDLen   [in/out] transaction id 버퍼가 저장될 버퍼의 버퍼사이즈(byte)
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nTxIDLen는 pTxID의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pTxID의 값을 NULL로 셋팅한후 호출시 nTxIDLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int GetTxID(const int coin_type,
                unsigned char* pRawTx, int nRawTxLen,
                unsigned char* pTxID, int* nTxIDLen);
    
    //ecdh not yet support
    //int GenECDHKeyPair( unsigned char* pPri , int nPriLen , unsigned char* pPub , int* nPubLen );
    //int GenECDHComputeShareKey( unsigned char* pOtherSidePub , int nOtherSidePubLen , unsigned char* pShareKey , int* nShareKeyLen );
    //int VerifyECDHComputeShareKey( unsigned char* pPri , int nPriLen , unsigned char* pOtherSidePub , int nOtherSidePubLen , unsigned char* pOtherSideShareKey , int nOtherSideShareKeyLen );
    
    /**
     @brief 보안값이 저장되어 있는 버퍼를 clear한다.
     @param pBuf           [in] 보안정보가 저장되어있는 버퍼
     @param nBufLen        [in] 보안정보 퍼버의 크기 ( byte )
     @see buf clear
     */
    
    /**
     @brief stdout에 로그를 출력하는 로그함수
     @see debug모드일때만 동작하므로 skip
     */
    WC_INTERFACE void PrintHex( const char* szPre , unsigned char* pData , int nDataLen );
    WC_INTERFACE void PrintDec( const char* szPre , unsigned char* pData , int nDataLen );
    WC_INTERFACE void PrintStr( const char* format , ... );
    
#ifdef __cplusplus
}
#endif

#endif //_PALLET_WALLET_CORE_LEGACY_INTERFACE_H_
