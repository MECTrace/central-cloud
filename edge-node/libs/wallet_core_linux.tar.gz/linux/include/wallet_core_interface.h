

/* ------------------------------- */
/* Version 0.2.2.1110.cc59 */
/* ------------------------------- */

#ifndef _PALLET_WALLET_CORE_INTERFACE_H_
#define _PALLET_WALLET_CORE_INTERFACE_H_

#define WALLET_CORE_INTERFACE_VER  "0.2.2.1110.cc59"

#define ECDSA_SECP256K1_NAME         "SECP256K1"
#define ECDSA_SECP256R1_NAME         "SECP256R1"
#define ECDSA_P256_NAME              "P256"
#define EDDSA_25519_NAME             "ED25519"

#define NOT_SUPPORT_ALGO        -1
#define ECDSA_SECP256K1         1
#define ECDSA_P256              2
#define EDDSA_25519             3

#ifdef WIN32
#ifdef INTERFACE_EXPORT
    #define WC_INTERFACE    __declspec(dllexport)
#else
    #define WC_INTERFACE    __declspec(dllimport)
#endif //INTERFACE_EXPORT
#else
#ifdef INTERFACE_EXPORT
    #define WC_INTERFACE    __attribute__((__visibility__("default")))
#else
    #define WC_INTERFACE
#endif //INTERFACE_EXPORT
#endif //WIN32

#ifdef WIN32
    #include <windows.h>
    #include <process.h>

    #define THREADHANDLE        HANDLE
    #define THREADID            DWORD
    #define CHECK_THREAD(h,i)      if ( 0 != h )
    #define THREAD_START(h,i,f,d)  h = (THREADHANDLE)_beginthreadex( NULL , 0 , (unsigned int(__stdcall*)(void*))f ,&d , 0 ,  (unsigned *)&i )

    #define HASYNC  CRITICAL_SECTION
    #define INIT_HASYNC(h)      InitializeCriticalSection( &h )
    #define UNINIT_HASYNC(h)    DeleteCriticalSection( &h )
    #define LOCK_HASYNC(h)      EnterCriticalSection( &h )
    #define UNLOCK_HASYNC(h)    LeaveCriticalSection( &h )
#else
    #include <pthread.h>

    #define HASYNC  pthread_mutex_t
    #define INIT_HASYNC(h)      pthread_mutex_init( &h , NULL )
    #define UNINIT_HASYNC(h)    pthread_mutex_destroy( &h )
    #define LOCK_HASYNC(h)      pthread_mutex_lock( &h )
    #define UNLOCK_HASYNC(h)    pthread_mutex_unlock( &h )

    #define THREADHANDLE        pthread_t
    #define THREADID            int
    #define CHECK_THREAD(h,i)      if ( 0 <= i )
    #define THREAD_START(h,i,f,d)  i = pthread_create( &h , NULL , f , (void*)&d )


#endif //WIN32

#ifdef __cplusplus
extern "C" {
#endif

    WC_INTERFACE int RunModule( const char* szJson , char** szRet );
    WC_INTERFACE int FreeMem( char* szRet );
    
#ifdef __cplusplus
}
#endif

#endif //_PALLET_WALLET_CORE_INTERFACE_H_
