

/* ------------------------------- */
/* Version 0.2.2.1110.cc59 */
/* ------------------------------- */


#ifndef _PALLET_BC_CIS_WRAPPER_H_
#define _PALLET_BC_CIS_WRAPPER_H_

#define BC_MODULE_VER  "0.2.2.1110.cc59"

#ifdef WIN32
#ifdef INTERFACE_EXPORT
    #define WC_INTERFACE    __declspec(dllexport)
#else
    #define WC_INTERFACE    __declspec(dllimport)
#endif //INTERFACE_EXPORT
#else
#ifdef INTERFACE_EXPORT
    #define WC_INTERFACE    __attribute__((__visibility__("default")))
#else
    #define WC_INTERFACE
#endif //INTERFACE_EXPORT
#endif //WIN32

#define PALLET_SUCCESS   0
#define PALLET_FAIL      1
#define PALLET_NEED_ADDSIG_TX 0xF0000000

//BASE58
#define NOR_BASE58_MAP      0
#define XRP_BASE58_MAP      1

//hash algo define
#define ALGO_NONE_HASH          0
#define ALGO_SHA256             1
#define ALGO_SHA512             2
#define ALGO_RIP160             3

#define ALGO_SHA3_KECCAK224     10
#define ALGO_SHA3_KECCAK256     11
#define ALGO_SHA3_KECCAK384     12
#define ALGO_SHA3_KECCAK512     13

#define BC_MODE_ECB        1
#define BC_MODE_CBC        2
#define BC_MODE_CFB        3
#define BC_MODE_OFB        5
#define BC_MODE_CTR        9
#define BC_MODE_GCM        11
#define BC_MODE_CCM        12

#define BC_NO_PAD       0
#define BC_PKCS7_PAD    1

#define MAX_HASH_BUF_LEN                    64
#define SHA256_MD_LEN                       32
#define SHA512_MD_LEN                       64
#define RIP160_MD_LEN                       20
#define SHA3_KECCAK224_MD_LEN               28
#define SHA3_KECCAK256_MD_LEN               32
#define SHA3_KECCAK384_MD_LEN               48
#define SHA3_KECCAK512_MD_LEN               64

#define MAX_MNEMONIC_WORD_LEN               11
#define MAX_MNEMONIC_CNT                    24
#define MAX_MNEMONIC_LEN                    MAX_MNEMONIC_WORD_LEN*MAX_MNEMONIC_CNT

#define SSS_MS_SPLITE           ';'
#define STR_SSS_MS_SPLITE       ";"

#define MAX_SSS_SHARE_CNT      10
#define MAX_SSS_MS_CNT         27
#define MAX_SSS_MS_BUFLEN      MAX_SSS_MS_CNT*MAX_MNEMONIC_WORD_LEN

#define BIP44_PATHCNT            5

#define ERROR_FNNAMELINE        64
#define ERROR_MSG_LEN           512

#define SIGRLEN                 33
#define SIGSLEN                 33

#define SEEDLEN                 64
#define PRILEN                  32
#define PUBLEN_UNCOMP           65
#define PUBLEN_COMP             33
#define PUBLEN_POINT            32
#define CHAINLEN                32

#define ED_PRILEN 32
#define ED_PUBLEN 32
#define ED_CHAINLEN 32
#define ED_SIGLEN 64

#define ASN1_SEQ        0x30
#define ASN1_BINT       0x02

#define COINTYPE_TESTNET             0x0F000000

#ifdef __cplusplus
extern "C" {
#endif
    
    /**
     @brief 에러 메시지를 리턴한다.
     @return const char* 에러 메시지
     @see pallet-core 함수의 리턴값이 PALLET_SUCCESS가 아닌경우 호출한다.
     */
    WC_INTERFACE const char *BCMGetLastErr(void);
    
    /**
     @brief Wallet-Core의 버전을 리턴한다.
     @return const char* 버전
     @see pallet-core 라이브러리의 버전을 리턴한다.
     */
    WC_INTERFACE const char* BCMGetVer(void);
    
    /**
     @brief 현재 runnig된 시스템의 endian을 알아온다.
     @return 1이면 little endian , 0이면 big endian
     */
    WC_INTERFACE int BCMGetCurrentSystemEndian(void);
    
    /**
     @brief 바이트의 순서를 바꾼다.
     @param pData     [in/out] 데이터 버퍼
     @param nDataLen  [in] 데이터 버퍼 사이즈 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int BCMSwapBytes( unsigned char* pData , const int nDataLen );
    
    /**
     @brief hex string을 byte array로 변환한다.
     @param szHexStr   [in] hex string이 저장될 버퍼
     @param pOut       [out] 생성된 byte array가 저장될 버퍼
     @param nOutLen    [in/out] 생성된 byte array 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see byte_len는 byte_arr의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see byte_arr의 값을 NULL로 셋팅한후 호출시 byte_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMConvHexStrToByteArr( const char* szHexStr , unsigned char* pOut , int* nOutLen );
    
    /**
     @brief byte array를 hex string으로 변환한다.
     @param pByte  [in] byte array가 저장될 버퍼
     @param nByteLen  [in] byte array버퍼의 크기 ( byte )
     @param nGenUpper   [in] 대문자로 생성할지 여부
     @param szOut   [out] 생성된 hex string이 저장될 버퍼
     @param nOutLen   [in/out] 생성된 hex string 버퍼의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see hex_len는 hex_str의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see hex_str의 값을 NULL로 셋팅한후 호출시 hex_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMConvByteArrToHexStr( const unsigned char* pByte , const int nByteLen , int nGenUpper , char* szOut , int* nOutLen );
    
    /**
     @brief array의 bit단위를 변환한다.
     @param pData  [in] input 데이터가 저장된 버퍼
     @param nDataLen  [in] input 데이터의 크기 ( byte )
     @param nFromBitLen  [in] input data의 bit단위
     @param nToBitLen   [in] 변경될 bit단위
     @param pOut   [out] 변환된 bit단위 데이터가 저장될 버퍼
     @param nOutLen   [in/out] 변환된 bit단위 데이터 버퍼의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see hex_len는 hex_str의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see hex_str의 값을 NULL로 셋팅한후 호출시 hex_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMConvBitToBit( const unsigned char* pData, const int nDataLen , const int nFromBitLen , const int nToBitLen , unsigned char* pOut , int* nOutLen );
    
    WC_INTERFACE int BCMGenBase64EncodeLen( const int nOriLen );
    /**
     @brief 대상값을 base64 encode한다.
     @param pOri     [in] base64 대상 값이 저장될 버퍼
     @param nOriLen  [in] base64 대상 값 버퍼의 크기 ( byte )
     @param szOut     [out] 생성된 base64 string 저장될 버퍼
     @param nOutLen   [in/out] 생성된 base64 string의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 szOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenBase64Encode( const unsigned char* pOri , const int nOriLen , char* szOut , int* nOutLen );
    
    /**
     @brief base64 encode된값을 base64 decode한다.
     @param szB64E      [in] base64 encode 값이 저장될 버퍼
     @param pOut     [out] 생성된 base64 decode값이 저장될 버퍼
     @param nOutLen  [in/out] 생성된 base64 decode값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenBase64Decode( const char* szB64E , unsigned char* pOut , int* nOutLen );
    
    WC_INTERFACE int BCMGenBase58CheckEncodeLen( const int nOriLen );
    /**
     @brief 대상값을 base58check encode한다.
     @param nUseMap     [in] xrp or normal ( XRP_BASE58_MAP or NOR_BASE58_MAP )
     @param pOri     [in] base58check 대상 값이 저장될 버퍼
     @param nOriLen  [in] base58check 대상 값 버퍼의 크기 ( byte )
     @param szOut     [out] 생성된 base58check string 저장될 버퍼
     @param nOutLen   [in/out] 생성된 base58check string의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 szOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenBase58CheckEncode( const int nUseMap , const unsigned char* pOri , const int nOriLen , char* szOut , int* nOutLen );
    
    /**
     @brief base58check encode된값을 base58 decode한다.
     @param nUseMap     [in] xrp or normal ( XRP_BASE58_MAP or NOR_BASE58_MAP )
     @param szB58E      [in] base58check encode 값이 저장될 버퍼
     @param pOut     [out] 생성된 base58 decode값이 저장될 버퍼
     @param nOutLen  [in/out] 생성된 base58 decode값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see pOutBuf에는 checksum값이 제외한 오리지널 값이 리턴된다.
     */
    WC_INTERFACE int BCMGenBase58CheckDecode( const int nUseMap , const char* szB58E , unsigned char* pOut , int* nOutLen );
    
    /**
     @brief 대상값을 base32 encode한다.
     @param pOri     [in] base32 대상 값이 저장될 버퍼
     @param nOriLen  [in] base32 대상 값 버퍼의 크기 ( byte )
     @param szOut     [out] 생성된 base32 string 저장될 버퍼
     @param nOutLen   [in/out] 생성된 base32 string의 크기 ( byte ) NULL제외
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 szOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenBase32Encode( unsigned char* pOri , int nOriLen , char* szOut , int* nOutLen );
    
    /**
     @brief base32 encode된값을 base32 decode한다.
     @param szB32E      [in] base32 encode 값이 저장될 버퍼
     @param pOut     [out] 생성된 base32 decode값이 저장될 버퍼
     @param nOutLen  [in/out] 생성된 base32 decode값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenBase32Decode( const char* szB32E , unsigned char* pOut , int* nOutLen );
    
    /**
     @brief 엔트로피(랜덤)값을 생성한다.
     @param pOut     [out] 생성된 엔트로피값이 저장될 버퍼
     @param nEntLen  [in] 생성할 엔트로피값의 크기 ( byte단위 )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int BCMGenEntropy( const int nEntLen , unsigned char* pOut );
    
    /**
     @brief 주어진 값의 hash(digest) 값을 생성 한다.
     @param nMDAlgo      [in] pallet-core에서 정의한 hash알고리즘
     ALGO_SHA256 : sha256 ( 결과값 32byte )
     ALGO_SHA512 : sha512 ( 결과값 64byte )
     ALGO_RIP160 : ripemd160 ( 결과값 20byte )
     ALGO_SHA3_KECCAK256 : sha3-keccat256 ( 결과값 32byte )
     @param pOri      [in] hash 대상 값이 저장될 버퍼
     @param nOriLen   [in] hash 대상 값 버퍼의 크기 ( byte )
     @param pOut     [out] 생성된 hash값이 저장될 버퍼
     @param nOutLen  [in/out] 생성된 hash값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nMDigestLen는 pMDigest의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pMDigest의 값을 NULL로 셋팅한후 호출시 nMDigestLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see 실제 알고리즘별 리턴되는 결과값은 nMDAlgo param의 결과값 참조
     */
    WC_INTERFACE int BCMGenHashMessage( const int nMDAlgo , const unsigned char* pOri , const int nOriLen , unsigned char* pOut , int* nOutLen );


    WC_INTERFACE int BCMGenHMac( const int nMDAlgo , const unsigned char* pKey , const int nKeyLen , const unsigned char* pOri , const int nOriLen ,
                                unsigned char* pOut , int* nOutLen );

    WC_INTERFACE int BCMGenPBKDF2( const int nMDAlgo , const char* szPwd , const unsigned char* pSalt , const int nSaltLen , const int nIterator , const int nDKLen ,
                                  unsigned char* pOut , int* nOutLen );

    WC_INTERFACE int BCMGenScrypt( const char* szPwd , const unsigned char* pSalt , const int nSaltLen , const int nN , const int nR , const int nP , const int nDKLen ,
                                  unsigned char* pOut , int* nOutLen );
    
    /**
     @brief 주어진 값을 AES128 or 256 -cbc-pkcs5padding or AES128 or 256-ecb-pkcs5padding 암호화 한다.
     @param pOri      [in] 암호화 대상 원본값이 저장될 버퍼
     @param nOriLen   [in] 암호화 대상 원본값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param nMode         [in] 암호화 Mode ( BC_ECB_MODE or BC_CBC_MODE )
     @param nPad          [in] 암호화 Mode ( BC_NO_PAD or BC_PKCS7_PAD )
     @param pOut       [out] 생성된 암호값이 저장될 버퍼
     @param nOutLen    [in/out] 생성된 암호값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nKeyLen이 16이면 AES128 32이면 AES256을 사용한다.
     @see nMode의 값은 BC_CBC or BC_CBC 만 지원한다.
     */
    WC_INTERFACE int BCMGenAESEncrypt( const unsigned char* pOri , const int nOriLen ,
                                      const unsigned char* pKey , const int nKeyLen , const unsigned char* pIV , const int nIVLen ,
                                      const int nMode , const int nPad ,
                                      unsigned char* pOut , int* nOutLen );
    
    /**
     @brief AES128 or 256-cbc-pkcs5padding or AES128 or 256-ecb-pkcs5padding 로 암호화된 값을 복호화 한다.
     @param pEnc      [in] 복호화 대상 암호값이 저장될 버퍼
     @param nEncLen   [in] 복호화 대상 암호값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param nMode         [in] 암호화 Mode ( BC_ECB_MODE or BC_CBC_MODE )
     @param nPad          [in] 암호화 Mode ( BC_NO_PAD or BC_PKCS7_PAD )
     @param pOut       [out] 생성된 원본값이 저장될 버퍼
     @param nOutLen    [in/out] 생성된 원본값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nKeyLen이 16이면 AES128 32이면 AES256을 사용한다.
     @see nMode의 값은 BC_CBC or BC_CBC 만 지원한다.
     */
    WC_INTERFACE int BCMGenAESDecrypt( const unsigned char* pEnc , const int nEncLen ,
                                      const unsigned char* pKey , const int nKeyLen , const unsigned char* pIV , const int nIVLen ,
                                      const int nMode , const int nPad ,
                                      unsigned char* pOut , int* nOutLen );
    
    
    /**
     @brief 주어진 값을 AES128-gcm 암호화 한다.
     @param pOri      [in] 암호화 대상 원본값이 저장될 버퍼
     @param nOriLen   [in] 암호화 대상 원본값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param pAuthData     [in] 인증값이 저장될 버퍼
     @param nAuthDataLen  [in] 인증값 버퍼의 크기 ( byte )
     @param nTagLen        [in] Tag 크기 ( byte )
     @param pOut       [out] 생성된 암호값이 저장될 버퍼
     @param nOutLen    [in/out] 생성된 암호값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nTagLen는 16보다 클수없음
     */
    WC_INTERFACE int BCMGenAESEncryptAuth( const unsigned char* pOri , const int nOriLen ,
                                      const unsigned char* pKey , const int nKeyLen , const unsigned char* pIV , const int nIVLen , const int nMode ,
                                      const unsigned char* pAuthData , const int nAuthDataLen , const int nTagLen ,
                                      unsigned char* pOut , int* nOutLen );
    
    /**
     @brief AES128-gcm으로 암호화된 값을 복호화 한다.
     @param pEnc      [in] 복호화 대상 암호값이 저장될 버퍼
     @param nEncLen   [in] 복호화 대상 암호값 버퍼의 크기 ( byte )
     @param pKey          [in] 암호화 키값이 저장될 버퍼
     @param nKeyLen       [in] 암호화 키값 버퍼의 크기 ( byte )
     @param pIV           [in] 암호화 IV값이 저장될 버퍼
     @param nIVLen        [in] 암호화 IV값 버퍼의 크기 ( byte )
     @param pAuthData     [in] 인증값이 저장될 버퍼
     @param nAuthDataLen  [in] 인증값 버퍼의 크기 ( byte )
     @param nTagLen        [in] Tag 크기 ( byte )
     @param pOut       [out] 생성된 원본값이 저장될 버퍼
     @param nOutLen    [in/out] 생성된 원본값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutBufLen는 pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOutBuf의 값을 NULL로 셋팅한후 호출시 nOutBufLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see nTagLen는 16보다 클수없음
     */
    WC_INTERFACE int BCMGenAESDecryptAuth( const unsigned char* pEnc , const int nEncLen ,
                                      const unsigned char* pKey , const int nKeyLen , const unsigned char* pIV , const int nIVLen , const int nMode ,
                                      const unsigned char* pAuthData , const int nAuthDataLen , const int nTagLen ,
                                      unsigned char* pOut , int* nOutLen );
    
    /**
     @brief 엔트로피값으로 니모닉을 생성한다.
     @param pEnt      [in] 엔트로피값이 저장된 버퍼
     @param nEntLen  [in] 엔트로피 버퍼 사이즈 ( byte )
     @param szOut          [out] 생성된 니모닉이 저장될 버퍼
     @param nOutLen      [in/out] 생성된 니모닉 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see buf(생성된 니모닉)의 단어별 구분은 스페이스
     @see buf_len는 buf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see buf의 값을 NULL로 셋팅한후 호출시 buf_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenMnemonic( const unsigned char* pEnt , const int nEntLen , char* szOut , int* nOutLen );
    
    /**
     @brief 엔트로피값으로 니모닉을 생성한다.
     @param szMnemonics      [in] 니모닉이 저장된 버퍼
     @param pOut          [out] 생성된 니모닉이 저장될 버퍼
     @param nOutLen      [in/out] 생성된 니모닉 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see buf(생성된 니모닉)의 단어별 구분은 스페이스
     @see buf_len는 buf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see buf의 값을 NULL로 셋팅한후 호출시 buf_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMConvMnemonicToEntropy( const char* szMnemonics , unsigned char* pOut , int* nOutLen );
    
    /**
     @brief 니모닉값으로 Master Seed값을 생성한다.
     @param szMnemonics   [in] 니모닉값이 저장된 버퍼
     @param szPassPharse  [in] 니모닉 유도를 위한 패스워드
     @param pOut           [out] 생성된 엔트로피가 저장될 버퍼
     @param nOutLen       [in/out] 생성된 엔트로피가 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see szMnemonics(생성된 니모닉)의 단어별 구분은 스페이스
     @see buf_len는 buf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see buf의 값을 NULL로 셋팅한후 호출시 buf_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMConvMnemonicToSeed( const char* szMnemonics , const char* szPassPharse , unsigned char* pOut , int* nOutLen );
    
    /**
     @brief 니모닉값의 유효성을 체크한다. ( 유효한 단어들로 이루어졌는지 , 니모닉 -> 엔트로피 : 체크섬값이 유효한지 )
     @param szMnemonics  [in] 니모닉값이 저장된 버퍼
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int BCMChkMnemonicValid(const char* szMnemonics);
    
    /**
     @brief 니모닉 단어값의 유효성을 체크한다. ( 유효한 단어인지 )
     @param szWord  [in] 니모닉 단어값이 저장된 버퍼
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     */
    WC_INTERFACE int BCMChkMnemonicWordValid(const char* szWord);
    
    /**
     @brief 마스터 니모닉값에서 시크릿 쉐어 니모닉 값들을 유도한다.
     @param szMMnemonic       [in] 마스터 니모닉값이 저장된 버퍼
     @param nTotalSSSMSCount  [int] 마스터 니모닉에 대한 전체 시크릿 니모닉의 갯수
     @param nNeedSSSMSCount   [in] 마스터 니모닉을 유도할 최소 시크릿 쉐어 니모닉의 갯수
     @param szSMnemonics      [out] 시크릿 쉐어 니모닉들이 저장될 버퍼
     @param nSMnemonicsLen    [in/out] 생성된 szSMnemonics 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see szMMnemonic(생성된 니모닉)의 단어별 구분은 스페이스
     @see nSMnemonicsLen는 szSMnemonics의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szSMnemonics의 값을 NULL로 셋팅한후 호출시 nSMnemonicsLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see 마스터 니모닉을 Entpropy로 치환 sharmir-secret-sharing을 이용 nTotalSSSMSCount개 만큼의 시크릿 쉐어 값을 시크릿 쉐어 니모닉으로 변환
     @see szSMnemonics의 니모닉별 구분자은 \n 이며 , 각 니모닉값의 단어별 구분은 스페이스임
     */
    WC_INTERFACE int BCMConvMasterMnemonicToSSSMnemonic(const char* szMMnemonic,
                                                        const int nTotalSSSMSCount, const int nNeedSSSMSCount,
                                                        char* szSMnemonics, int* nSMnemonicsLen);
    
    /**
     @brief 시크릿 쉐어 니모닉값에서 마스터 니모닉 값을 유도한다.
     @param szSMnemonics   [in] 시크릿 쉐어 니모닉값들이 저장된 버퍼
     @param szMMnemonics   [out] 마스터 니모닉이 저장될 버퍼
     @param nMMnemonicLen  [in/out] 생성된 szMMnemonics 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see szSMnemonics의 니모닉별 구분자은 \n 이며 , 각 니모닉값의 단어별 구분은 스페이스임
     @see szMMnemonics는 nMMnemonicLen의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see szMMnemonics의 값을 NULL로 셋팅한후 호출시 nMMnemonicLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see szMMnemonics의 각 단어별 구분은 스페이스임
     */
    WC_INTERFACE int BCMConvSSSMnemonicToMasterMnemonic(const char* szSMnemonics,
                                                        char* szMMnemonics, int* nMMnemonicLen);
    
    /**
     @brief 마스터 노드를 생성한다. ( bip44 m' )
     @param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
     @param pMasterSeed      [in] Master Seed값이 저장된 버퍼
     @param nMasterSeedLen  [in] Master Seed 버퍼 사이즈 ( byte )
     @param pPri         [out] 생성된 마스터 노드의 개인키가 저장될 버퍼
     @param nPriLen         [in/out] 생성된 마스터 노드의 개인키 버퍼의 크기 ( byte )
     @param pPub          [out] 생성된 마스터 노드의 공개키가 저장될 버퍼
     @param nPubLen          [in/out] 생성된 마스터 노드의 공개키 버퍼의 크기 ( byte )
     @param pChainCode       [out] 생성된 마스터 노드의 체인코드가 저장될 버퍼
     @param nChainCodeLen        [in/out] 생성된 마스터 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위한 GenCKD/GenCKDPub를 호출하기 위한 마스터 노드 생성을 위해 호출한다.
     @see priv_len/pub_len/chain_len는 priv_key/pub_key/chain_code의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see priv_key/pub_key/chain_code의 값을 NULL로 셋팅한후 호출시 priv_len/pub_len/chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenMasterNode( const int nUse256P1 , const unsigned char* pMasterSeed , const int nMasterSeedLen ,
                                      unsigned char* pPri , int* nPriLen ,
                                      unsigned char* pPub , int* nPubLen ,
                                      unsigned char* pChainCode , int* nChainCodeLen );
    
    /**
     @brief 부모 노드로 부터 자식 노드를 생성한다. ( bip44 m'/.... )
     @param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
     @param pPPri      [in] 부모 노드의 개인키값이 저장된 버퍼
     @param nPPriLen      [in] 노드의 개인키 버퍼 사이즈 ( byte )
     @param pPPub       [in] 부모 노드의 공개키값이 저장된 버퍼
     @param nPPubLen       [in] 노드의 공개키 버퍼 사이즈 ( byte )
     @param pPChainCode    [in] 부모 노드의 체인코드값이 저장된 버퍼
     @param nPChainCodeLen     [in] 노드의 체인코드 버퍼 사이즈 ( byte )
     @param nIndex             [in] 자식 노드의 index
     @param pCPri    [out] 생성된 자식 노드의 개인키가 저장될 버퍼
     @param nCPriLen    [in/out] 생성된 자식 노드의 개인키 버퍼의 크기 ( byte )
     @param pCPub     [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param nCPubLen     [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param pCChainCode  [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param nCChainCodeLen   [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위해서 호출한다.
     @see hardened 자식노드를 호출하기 위해서는 index값에 0x80000000를 더해준다.
     @see child_priv_len/child_pub_len/child_chain_len는 child_priv_key/child_pub_key/child_chain_code의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see child_priv_key/child_pub_key/child_chain_code의 값을 NULL로 셋팅한후 호출시 child_priv_len/child_pub_len/child_chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenCKD( const int nUse256P1 , const unsigned char* pPPri , const int nPPriLen ,
                               const unsigned char* pPPub , const int nPPubLen ,
                               const unsigned char* pPChainCode , const int nPChainCodeLen,
                               const unsigned int nIndex ,
                               unsigned char* pCPri , int* nCPriLen ,
                               unsigned char* pCPub , int* nCPubLen ,
                               unsigned char* pCChainCode , int* nCChainCodeLen );
    
    /**
     @brief 부모 노드로 부터 자식 노드의 공개키를 생성한다. ( bip44 m'/.... )
     @param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
     @param pPPub       [in] 부모 노드의 공개키값이 저장된 버퍼
     @param nPPubLen       [in] 노드의 공개키 버퍼 사이즈 ( byte )
     @param pPChainCode    [in] 부모 노드의 체인코드값이 저장된 버퍼
     @param nPChainCodeLen     [in] 노드의 체인코드 버퍼 사이즈 ( byte )
     @param nIndex             [in] 자식 노드의 index
     @param pCPub     [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param nCPubLen     [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param pCChainCode  [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param nCChainCodeLen   [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위해서 호출한다.
     @see 부모->자식 생성시 공개키로 유도시는 hardened 자식노드의 생성은 불가함
     @see child_pub_len/child_chain_len는 child_pub_key/child_chain_code의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see child_pub_key/child_chain_code의 값을 NULL로 셋팅한후 호출시 child_pub_len/child_chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenCKDPub( const int nUse256P1 , const unsigned char* pPPub , const int nPPubLen ,
                                  const unsigned char* pPChainCode , const int nPChainCodeLen,
                                  const unsigned int nIndex ,
                                  unsigned char* pCPub , int* nCPubLen ,
                                  unsigned char* pCChainCode , int* nCChainCodeLen );
    
    /**
     @brief Master Seed로 부터 리프 노드를 생성한다. ( bip44 m/purpose'[0x8000002c]/coin_type'[0x80000000+Slip44Index]/account'[0x80000000]/change[0]/address_index[address_index] )
     @param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
     @param pMasterSeed      [in] Master Seed값이 저장된 버퍼
     @param nMasterSeedLen  [in] Master Seed 버퍼 사이즈 ( byte )
     @param nPurpose          [in] 자식 노드의 purpose'
     @param nCoinType        [in] 자식 노드의 coin type'
     @param nAccountIdx    [in] 자식 노드의 account' index
     @param nChangeIdx     [in] 자식 노드의 chnage index
     @param nAddressIdx    [in] 자식 노드의 address index
     @param pPri         [out] 생성된 자식 노드의 개인키가 저장될 버퍼
     @param nPriLen         [in/out] 생성된 자식 노드의 개인키 버퍼의 크기 ( byte )
     @param pPub          [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param nPubLen          [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param pChainCode       [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param nChainCodeLen        [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see 테스트용임 절대 실제 서비스에서는 사용금지
     @see bip44패스 입력 ( default m/purpose(42)'/coin_type(slip44)'/account_index(0)'/change(0)/address(0) )
     @see priv_key/pub_key/chain_code의 값을 NULL로 셋팅한후 호출시 priv_len/pub_len/chain_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenPathLeafNode( const int nUse256P1 , const unsigned char* pMasterSeed , const int nMasterSeedLen ,
                                        const unsigned int nPurpose , const unsigned int nCoinType , const unsigned int nAccountIdx ,
                                        const unsigned int nChangeIdx , const unsigned int nAddressIdx ,
                                        unsigned char* pPri , int* nPriLen ,
                                        unsigned char* pPub , int* nPubLen ,
                                        unsigned char* pChainCode , int* nChainCodeLen );
        
    /**
     @brief 개인키(32byte)로 부터 압축된 공개키(33byte)를 생성한다.
     @param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
     @param pPri  [in] 개인키값이 저장된 버퍼
     @param nPriLen  [in] 개인키 버퍼 사이즈 ( byte )
     @param pOut   [out] 생성된 공개키가 저장될 버퍼
     @param nOutLen   [in/out] 생성된 공개키 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see 생성된 공개키는 압축된 형태임 ( 1byte[prefix : y is odd(0x03) or even(0x02)]+32byte[public key's x point] )
     @see pub_len는 pub_key의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pub_key의 값을 NULL로 셋팅한후 호출시 pub_len값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenPubkeyFromPriKey( const int nUse256P1 , const unsigned char* pPri , const int nPriLen , unsigned char* pOut , int* nOutLen );
    
	/**
	@brief 압축된 공개키(32byte)로 부터 Y Point값을 유도한다.
	@param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
	@param pCompPub  [in] 압축된 공개키값이 버퍼
	@param nCompPubLen  [in]  압축된 공개키 버퍼 사이즈 ( byte )
	@param pPubY   [out] 생성된 공개키의 Y Point가 저장될 버퍼
	@param nPubYLen   [in/out] 생성된 공개키의 Y Point 버퍼의 크기 ( byte )
	@return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
	@see 생성된 Y Point는 32 byte임
	@see nPubYLen는 pPubY의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
	@see pPubY의 값을 NULL로 셋팅한후 호출시 nPubYLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
	*/
    WC_INTERFACE int BCMGetPubYFromCompPub(const int nUse256P1, const unsigned char* pCompPub, const int nCompPubLen, unsigned char* pPubY, int* nPubYLen);

	/**
	@brief ecdsa 전자서명을 생성한다.
	@param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
	@param pPri  [in] 개인키값 버퍼
	@param nPriLen  [in]  개인키 버퍼 사이즈 ( byte )
	@param nHashAlgo  [in]  서명 원본값을 해쉬할 해쉬 알고리즘
	@param pMsg  [in]  서명 원본값 버퍼
	@param nMsgLen  [in]  서명 원본값 버퍼 사이즈 ( byte )
	@param nUseOriSigS  [in]  Low_S값 사용여부 
	@param pSigR   [out] 생성된 전자서명의 R값이 저장될 버퍼
	@param nSigRLen   [in/out] 생성된 전자서명의 R값 의 크기 ( byte )
	@param pSigS   [out] 생성된 전자서명의 S값이 저장될 버퍼
	@param nSigSLen   [in/out] 생성된 전자서명의 S값 의 크기 ( byte )
	@param nRecovery   [out] 생성된 전자서명의 Recovery값이 저장될 버퍼
	@return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
	@see 생성된 SigR / SigS 는 32-33 byte임 (33byte일때는 00이 붙는다 - signed byte - )
	@see nSigRLen/nSigSLen는 pSigR/pSigS의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
	@see pSigR/pSigS의 값을 NULL로 셋팅한후 호출시 nSigRLen/nSigSLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
	@see nHashAlgo는 ALGO_NONE_HASH / ALGO_SHA256 / ALGO_SHA3_KECCAK256 만 사용가능 ( ALGO_NONE_HASH 사용시 pMsg는 해쉬된 원본값으로 해야함 )
	@see nUseOriSigS Low_S의 사용 여부 ( 1 이면 원본값 , 0 이면 Low_S ) 참조 : bip146 ( LOW_S )
	*/
    WC_INTERFACE int BCMGenSignature( const int nUse256P1 ,
                                     const unsigned char* pPri , const int nPriLen ,
                                     const int nHashAlgo , const unsigned char* pMsg , const int nMsgLen , const int nUseOriSigS ,
                                     unsigned char* pSigR , int* nSigRLen , unsigned char* pSigS , int* nSigSLen , int* nRecovery );
    
	/**
	@brief ecdsa 전자서명을 검증한다.
	@param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
	@param pPub  [in] 공개키값 버퍼
	@param nPubLen  [in]  공개키 버퍼 사이즈 ( byte )
	@param pSigR   [in] 전자서명의 R값 버퍼
	@param nSigRLen   [in] 전자서명의 R값 의 크기 ( byte )
	@param pSigS   [in] 전자서명의 S값 버퍼
	@param nSigSLen   [in] 전자서명의 S값 의 크기 ( byte )
	@param nHashAlgo  [in]  서명 원본값을 해쉬할 해쉬 알고리즘
	@param pMsg  [in]  서명 원본값 버퍼
	@param nMsgLen  [in]  서명 원본값 버퍼 사이즈 ( byte )
	@return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
	@see nHashAlgo는 ALGO_NONE_HASH / ALGO_SHA256 / ALGO_SHA3_KECCAK256 만 사용가능 ( ALGO_NONE_HASH 사용시 pMsg는 해쉬된 원본값으로 해야함 )
	*/
    WC_INTERFACE int BCMVerifySignature( const int nUse256P1 ,
                                        const unsigned char* pPub , const int nPubLen ,
                                        const unsigned char* pSigR , const int nSigRLen , const unsigned char* pSigS , const int nSigSLen ,
                                        const int nHashAlgo , const unsigned char* pMsg , const int nMsgLen );

    /**
     @brief ED25519를 지원하는 마스터 노드를 생성한다. ( bip44 m' )
     @param pMasterSeed      [in] Master Seed값이 저장된 버퍼
     @param nMasterSeedLen   [in] Master Seed 버퍼 사이즈 ( byte )
     @param pPri             [out] 생성된 마스터 노드의 개인키가 저장될 버퍼
     @param nPriLen          [in/out] 생성된 마스터 노드의 개인키 버퍼의 크기 ( byte )
     @param pPub             [out] 생성된 마스터 노드의 공개키가 저장될 버퍼
     @param nPubLen          [in/out] 생성된 마스터 노드의 공개키 버퍼의 크기 ( byte )
     @param pChainCode       [out] 생성된 마스터 노드의 체인코드가 저장될 버퍼
     @param nChainCodeLen    [in/out] 생성된 마스터 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위한 GenCKD_ED를 호출하기 위한 마스터 노드 생성을 위해 호출한다.
     @see nPriLen/nPubLen/nChainCodeLen는 pPri/pPub/pChainCode의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pPri/pPub/pChainCode의 값을 NULL로 셋팅한후 호출시 nPriLen/nPubLen/nChainCodeLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenMasterNode_ED(const unsigned char* pMasterSeed , const int nMasterSeedLen ,
                                         unsigned char* pPri , int* nPriLen ,
                                         unsigned char* pPub , int* nPubLen ,
                                         unsigned char* pChainCode , int* nChainCodeLen );
    
    /**
     @brief ED25519를 지원하는 부모 노드로 부터 자식 노드를 생성한다. ( bip44 m'/.... )
     @param pPPri          [in] 부모 노드의 개인키값이 저장된 버퍼
     @param nPPriLen       [in] 노드의 개인키 버퍼 사이즈 ( byte )
     @param pPPub          [in] 부모 노드의 공개키값이 저장된 버퍼
     @param nPPubLen       [in] 노드의 공개키 버퍼 사이즈 ( byte )
     @param pPChainCode    [in] 부모 노드의 체인코드값이 저장된 버퍼
     @param nPChainCodeLen [in] 노드의 체인코드 버퍼 사이즈 ( byte )
     @param nIndex          [in] 자식 노드의 index
     @param pCPri          [out] 생성된 자식 노드의 개인키가 저장될 버퍼
     @param nCPriLen       [in/out] 생성된 자식 노드의 개인키 버퍼의 크기 ( byte )
     @param pCPub          [out] 생성된 자식 노드의 공개키가 저장될 버퍼
     @param nCPubLen       [in/out] 생성된 자식 노드의 공개키 버퍼의 크기 ( byte )
     @param pCChainCode    [out] 생성된 자식 노드의 체인코드가 저장될 버퍼
     @param nCChainCodeLen [in/out] 생성된 자식 노드의 체인코드 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see bip44 각 단계별 자식노드를 유도하기 위해서 호출한다.
     @see hardened만 지원하기때문 nIndex값은 0x80000000이상이여야함.
     @see nCPriLen/nCPubLen/nCChainCodeLen는 pCPri/pCPub/pCChainCode의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pCPri/pCPub/pCChainCode의 값을 NULL로 셋팅한후 호출시 nCPriLen/nCPubLen/nCChainCodeLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenCKD_ED(const unsigned char* pPPri, int nPPriLen,
                                  const unsigned char* pPPub, int nPPubLen,
                                  const unsigned char* pPChainCode, int nPChainCodeLen,
                                  const int nIndex,
                                  unsigned char* pCPri, int* nCPriLen,
                                  unsigned char* pCPub, int* nCPubLen,
                                  unsigned char* pCChainCode, int* nCChainCodeLen);
    
    //ed25519 not support none hardend ckd
    /*
    WC_INTERFACE int BCMGenPathLeafNode_ED( const unsigned char* pMasterSeed , const int nMasterSeedLen ,
                                           const unsigned int nPurpose , const unsigned int nCoinType , const unsigned int nAccountIdx ,
                                           const unsigned int nChangeIdx , const unsigned int nAddressIdx ,
                                           unsigned char* pPri , int* nPriLen ,
                                           unsigned char* pPub , int* nPubLen ,
                                           unsigned char* pChainCode , int* nChainCodeLen );
    */
    
    
    /**
     @brief ED25519 개인키(32byte)로 부터 공개키(32byte)를 생성한다.
     @param pPri     [in] 개인키값이 저장된 버퍼
     @param pPriLen  [in] 개인키 버퍼 사이즈 ( byte )
     @param pPub     [out] 생성된 공개키가 저장될 버퍼
     @param nPubLen  [in/out] 생성된 공개키 버퍼의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nPubLen는 pPub의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pPub의 값을 NULL로 셋팅한후 호출시 nPubLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     */
    WC_INTERFACE int BCMGenPubkeyFromPriKey_ED(const unsigned char* pPri , const int pPriLen , unsigned char* pOut , int* nOutLen );
    
	/**
	@brief ED25519 전자서명을 생성한다.
	@param pPri  [in] 개인키값 버퍼
	@param nPriLen  [in]  개인키 버퍼 사이즈 ( byte )
	@param pMsg  [in]  서명 원본값 버퍼
	@param nMsgLen  [in]  서명 원본값 버퍼 사이즈 ( byte )
	@param pContext  [in]  서명에 사용될 context값 버퍼
	@param nContextLen  [in]  context값 버퍼 사이즈 ( byte )
	@param cUsePh  [in]  서명 생성시 ph모드 사용여부
	@param pOut   [out] 생성된 전자서명이 저장될 버퍼
	@param nOutLen   [in/out] 생성된 전자서명의 크기 ( byte )
	@return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
	@see 생성된 전자서명 값의 크기는 일반적으로 64 byte임
	@see nOutLen는 pOut의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
	@see pOut의 값을 NULL로 셋팅한후 호출시 nOutLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
	*/
    WC_INTERFACE int BCMGenSignature_ED(const unsigned char* pPri , const int nPriLen ,
                                        const unsigned char* pMsg , const int nMsgLen ,
                                        const unsigned char* pContext , const int nContextLen ,
                                        const unsigned char cUsePh ,
                                        unsigned char* pOut , int* nOutLen );

	/**
	@brief ED25519 전자서명을 검증한다.
	@param pSig   [in] 전자서명값 버퍼
	@param nSigLen   [in] 전자서명값 의 크기 ( byte )
	@param pPub  [in] 공개키값 버퍼
	@param nPubLen  [in]  공개키 버퍼 사이즈 ( byte )
	@param pMsg  [in]  서명 원본값 버퍼
	@param nMsgLen  [in]  서명 원본값 버퍼 사이즈 ( byte )
	@param pContext  [in]  서명에 사용될 context값 버퍼
	@param nContextLen  [in]  context값 버퍼 사이즈 ( byte )
	@param cUsePh  [in]  서명 생성시 ph모드 사용여부
	@return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
	*/
    WC_INTERFACE int BCMVerifySignature_ED(const unsigned char* pSig , const int nSigLen ,
                                            const unsigned char* pPub , const int nPubLen ,
                                            const unsigned char* pMsg , const int nMsgLen ,
                                            const unsigned char* pContext , const int nContextLen ,
                                            const unsigned char cUsePh );

    /**
     @brief 주어진 값을 ECIES 암호화 한다.
     @param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
     @param pOri      [in] 암호화 대상 원본값이 저장될 버퍼
     @param nOriLen   [in] 암호화 대상 원본값 버퍼의 크기 ( byte )
     @param pEncrypterPriKey          [out] 암호화값에 사용된 상대방의 공개키
     @param nEncrypterPriKeyLen       [in/out] 암호화값에 사용된 상대방의 공개키값 버퍼의 크기 ( byte )
     @param pDecrypterPubKey          [in] 암호화값을 복호화할 유저의 공개키
     @param nDecrypterPubKeyLen       [in] 암호화값을 복호화할 유저의 공개키값 버퍼의 크기 ( byte )
     @param pOut       [out] 생성된 암호값이 저장될 버퍼
     @param nOutLen    [in/out] 생성된 암호값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nRandPubKeyLen/nOutLen는 pRanPubKey/pOutBuf의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pRanPubKey/pOut의 값을 NULL로 셋팅한후 호출시 nRandPubKeyLen/nOutLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see Decrypter Pub ( compress ,uncompress 사용 가능하다 ), Random Pub ( compress 된 값이다 )
     @see pRanPubKey값은 내부적으로 생성한 랜덤값에 대한 , 공개키 값이다.
     @see key derivate 시 pbkdf2를 사용하며 펜타의 내부 커스텀 값을 사용한다. ( pbkdf ( hash , salt , iterator ) )
     @see 결과값의 마지막 32byte값은 암호화 값의 검증을 위해 사용된다.
     @see 사용되는 대칭키 암호화는 aes128-cbc-pkcs7padding 을 사용한다. PKI알고리즘은 ecdsa를 사용하며 지원되는 커브는 p256 / secp256k1 이다
     */
    WC_INTERFACE int BCMGenECIESEncrypt( const int nUse256P1 , const unsigned char* pOri , const int nOriLen ,
                                         const unsigned char* pEncrypterPriKey , const int nEncrypterPriKeyLen ,
                                         const unsigned char* pDecrypterPubKey , const int nDecrypterPubKeyLen ,
                                         unsigned char* pOut , int* nOutLen );

/**
     @brief 주어진 값을 ECIES 암호화 한다.
     @param nUse256P1      [in] ecdsa 256p1 사용 여부 1이 아니면 256k1
     @param pEnc      [in] 복호화 대상 암호값이 저장될 버퍼
     @param nEncLen   [in] 복호화 대상 암호값 버퍼의 크기 ( byte )
     @param pDecrypterPriKey          [in] 암호화값을 복호화할 유저의 개인키
     @param nDecrypterPriKeyLen       [in] 암호화값을 복호화할 유저의 개인키값 버퍼의 크기 ( byte )
     @param pOut       [out] 생성된 원본값이 저장될 버퍼
     @param nOutLen    [in/out] 생성된 원본값의 크기 ( byte )
     @return 성공시 PALLET_SUCCESS, 실패시 PALLET_FAIL
     @see nOutLen는 pOut의 크기값(byte)으로 셋팅, 리턴시 실제 생성된 크기값이 셋팅됨
     @see pOut의 값을 NULL로 셋팅한후 호출시 nOutLen값에 생성될 버퍼의 크기값이 셋팅되어 리턴됨
     @see Random Pub ( compress 된 값이다 )
     @see key derivate 시 pbkdf2를 사용하며 펜타의 내부 커스텀 값을 사용한다. ( pbkdf ( hash , salt , iterator ) )
     @see 암호화 값의 마지막 32byte값은 암호화 값의 검증을 위해 사용된다.
     @see 사용되는 대칭키 암호화는 aes128-cbc-pkcs7padding 을 사용한다. PKI알고리즘은 ecdsa를 사용하며 지원되는 커브는 p256 / secp256k1 이다
     */
    WC_INTERFACE int BCMGenECIESDecrypt( const int nUse256P1 , const unsigned char* pEnc , const int nEncLen ,
                                        const unsigned char* pDecrypterPriKey , const int nDecrypterPriKeyLen ,
                                        unsigned char* pOut , int* nOutLen );

    //Todo ecdh not yet support
	WC_INTERFACE int BCMGenECDHKeyPair(const int nUse256P1, unsigned char* pPri, int* nPriLen, unsigned char* pPub, int* nPubLen);
	WC_INTERFACE int BCMGenECDHComputeShareKey(const int nUse256P1, 
		const unsigned char* pPri, const int nPriLen, const unsigned char* pPeerPub, const int nPeerPubLen,
		unsigned char* pShare, int* nShareLen);
		
    
    /**
     @brief stdout에 로그를 출력하는 로그함수
     @see debug모드일때만 동작하므로 skip
     */
    WC_INTERFACE void BCMPrintHex( const char* szPre , unsigned char* pData , int nDataLen );
    WC_INTERFACE void BCMPrintDec( const char* szPre , unsigned char* pData , int nDataLen );
    WC_INTERFACE void BCMPrintStr( const char* format , ... );
    
#ifdef __cplusplus
}
#endif

#endif //_PALLET_BC_CIS_WRAPPER_H_
