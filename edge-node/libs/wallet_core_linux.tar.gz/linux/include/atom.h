//
// Created by hjpark on 2018. 9. 5..
//

/* ------------------------------- */
/* Version 0.2.2.1110.cc59 */
/* ------------------------------- */

#ifndef PALLET_CORE_ATOM_H
#define PALLET_CORE_ATOM_H

#define ADDON_ATOM_VER  "0.2.2.1110.cc59"

#ifdef WIN32
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __declspec(dllexport)
#else
#define BC_ADDON_INTERFACE    __declspec(dllimport)
#endif //ADDON_EXPORT
#else
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __attribute__((__visibility__("default")))
#else
#define BC_ADDON_INTERFACE
#endif //ADDON_EXPORT
#endif //WIN32

#define ATOM_ADDR_HRP                   "cosmos1"
#define ATOM_VAL_OPER_ADDR_HRP          "cosmosvaloper1"
#define ATOM_VAL_CONS_ADDR_HRP          "cosmosvalcons1"

#define ATOM_PUB_HRP                   "cosmospub1"
#define ATOM_VAL_OPER_PUB_HRP          "cosmosvaloperpub1"
#define ATOM_VAL_CONS_PUB_HRP          "cosmosvalconspub1"

#define ATOM_PUB_PREFIX_SECP256K1      "0xEB5AE987"
#define ATOM_PUB_PREFIX_ED25519        "0x1624DE64"

#define ATOM_BECH32_CHECKSUM_LEN        6



#ifdef __cplusplus
extern "C" {
#endif
    
	BC_ADDON_INTERFACE int RunModule_ATOM( const char* szAction , const char* szCoinName , const char* szJson , char** szRet );
	BC_ADDON_INTERFACE int FreeMem_ATOM( char* szRet );
    
    
#ifdef __cplusplus
}
#endif

#endif //PALLET_CORE_ATOM_H
