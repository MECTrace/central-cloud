//
// Created by hjpark on 2018. 9. 5..
//

/* ------------------------------- */
/* Version 0.2.2.1110.cc59 */
/* ------------------------------- */

#ifndef PALLET_CORE_ATOM_H
#define PALLET_CORE_ATOM_H

#define ADDON_AMO_VER  "0.2.2.1110.cc59"

#ifdef WIN32
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __declspec(dllexport)
#else
#define BC_ADDON_INTERFACE    __declspec(dllimport)
#endif //ADDON_EXPORT
#else
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __attribute__((__visibility__("default")))
#else
#define BC_ADDON_INTERFACE
#endif //ADDON_EXPORT
#endif //WIN32

#ifdef __cplusplus
extern "C" {
#endif
    
	BC_ADDON_INTERFACE int RunModule_AMO( const char* szAction , const char* szCoinName , const char* szJson , char** szRet );
	BC_ADDON_INTERFACE int FreeMem_AMO( char* szRet );    
    
#ifdef __cplusplus
}
#endif

#endif //PALLET_CORE_ATOM_H
