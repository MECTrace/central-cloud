//
// Created by hjpark on 2018. 9. 5..
//

/* ------------------------------- */
/* Version 0.2.2.1110.cc59 */
/* ------------------------------- */

#ifndef PALLET_CORE_BITCOIN_H
#define PALLET_CORE_BITCOIN_H

#define ADDON_BTC_VER  "0.2.2.1110.cc59"

#ifdef WIN32
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __declspec(dllexport)
#else
#define BC_ADDON_INTERFACE    __declspec(dllimport)
#endif //ADDON_EXPORT
#else
#ifdef ADDON_EXPORT
#define BC_ADDON_INTERFACE    __attribute__((__visibility__("default")))
#else
#define BC_ADDON_INTERFACE
#endif //ADDON_EXPORT
#endif //WIN32

//OP_CODE
#define OP_PUSHDATA1         0x4c
#define OP_PUSHDATA2         0x4d
#define OP_PUSHDATA4         0x4e
#define OP_RETURN            0x6a
#define OP_DUP               0x76
#define OP_HASH160           0xa9
#define OP_EQUALVERIFY       0x88
#define OP_CHECKSIG          0xac
#define OP_EQUAL             0x87
#define OP_CHECKMULTISIG     0xae
#define OP_CHECKMULTISIGVERIFY 0xaf
#define OP_0                 0x00
#define OP_START             0x50
#define OP_n(a)              (0<a?OP_START+a:OP_0)

#define BTC_HRP_LEN                   3
#define BTC_BECH32_HRP                "bc1"
#define BTC_BECH32_HRP_TEST           "tb1"

#define BTC_BECH32_CHECKSUM_LEN 6
#define BTC_WITNESS_VERSION      0x00

#define BTC_SPEC "{\"coin\":\"btc\",\"hrplen\":\"3\",\"bech32hrp\":\"bc1\",\"bech32hrptest\":\"tb1\",\"hashtype\":\"0x01000000\"}"

// LTC
#define LTC_HRP_LEN              5
#define LTC_BECH32_HRP                "ltc1"
#define LTC_BECH32_HRP_TEST           "tltc1"

#define LTC_SPEC "{\"coin\":\"ltc\",\"hrplen\":5,\"bech32hrp\":\"ltc1\",\"bech32hrptest\":\"tltc1\",\"hashtype\":\"0x01000000\"}"

//bitcoin gold
#define BTG_HRP_LEN              5
#define BTG_BECH32_HRP                "btg1"
#define BTG_BECH32_HRP_TEST           "tbtg1"
#define BTG_SPEC "{\"coin\":\"btg\",\"hrplen\":5,\"bech32hrp\":\"btg1\",\"bech32hrptest\":\"tbtg1\",\"hashtype\":\"0x414f0000\"}"

//bitcoin cash
#define BCH_HRP_LEN                 12
#define BCH_CASHADDR_HRP                "bitcoincash:"
#define BCH_CASHADDR_HRP_TEST           "bchtest:"
#define BCH_CASHADDR_CHECKSUM_LEN   8
#define BCH_ADDR_P2SH_CASH_VERSION 0x08
#define BCH_SPEC "{\"coin\":\"bch\",\"hrplen\":12,\"bech32hrp\":\"bitcoincash:\",\"bech32hrptest\":\"bchtest:\",\"hashtype\":\"0x41000000\"}"

//bitcoin satoshi version ( sv )
#define BSV_HRP_LEN                 12
#define BSV_CASHADDR_HRP                "bitcoincash:"
#define BSV_CASHADDR_HRP_TEST           "bchtest:"
#define BSV_SPEC "{\"coin\":\"bsv\",\"hrplen\":12,\"bech32hrp\":\"bitcoincash:\",\"bech32hrptest\":\"bchtest:\",\"hashtype\":\"0x41000000\"}"


enum EBTC_ADDR_TYPE
{
    EADDR_NONE           = 10 ,
    EADDR_P2PKH          ,
    EADDR_P2SH_P2WPKH    ,
    EADDR_P2WPKH         ,
    EADDR_P2SH           ,
    EADDR_P2SH_P2WSH     ,
    EADDR_P2WSH          ,
    EADDR_P2PKH_BITPAY   ,
    EADDR_P2SH_BITPAY    ,
    EADDR_P2PKH_CASH     ,
    EADDR_P2SH_CASH      ,
    EADDR_END            = 100
};

#ifdef __cplusplus
extern "C" {
#endif
    
	BC_ADDON_INTERFACE int RunModule_BTC( const char* szAction , const char* szCoinName , const char* szJson , char** szRet );
	BC_ADDON_INTERFACE int FreeMem_BTC( char* szRet );
    
    
#ifdef __cplusplus
}
#endif

#endif //PALLET_CORE_BITCOINCASH_H
